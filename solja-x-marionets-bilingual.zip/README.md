# Solja X Marionets <3

Windows x64 menu. The current build has no World Effects code or Chams module. UI language can be switched in Settings and is saved in named configs.

## Configs

The Config tab lists saved `.ini` profiles from `%APPDATA%\Solja X Marionets\configs`. Select one to load it, type a name to save a profile, and use Refresh list after external changes.

## Build

Visual Studio 2022, v143, x64 Release. Build `D3D11 Overlay ImGui.sln`. Set `DXSDK_DIR` to the `D3D11 Overlay ImGui` project directory, which contains the bundled ImGui and DirectX SDK files.
