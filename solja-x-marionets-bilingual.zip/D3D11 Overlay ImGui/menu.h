#pragma once
#include <Windows.h>
#include "ImGui/imgui.h"

namespace Menu
{
    // ESP
    extern bool   espBox, espSnaplines, espFill, espHeadCircle, customCrosshair;
    extern ImVec4 colEspBox, colEspSnaplines, colEspFill, colEspHeadCircle, colCrosshair;

    // Box options
    extern int boxMode;
    extern float espLineThickness;

    // Snaplines options
    extern int snaplineMode;

    // Fill alpha
    extern float fillAlpha, snaplineOpacity;

    // Crosshair options
    extern int crosshairMode;
    extern float crosshairSize, crosshairGap, crosshairThickness;
    extern bool useSharedVisualColor;
    extern ImVec4 colSharedVisual;

    // RGB States
    struct RgbState { bool enabled = false; float speed = 1.f; float hue = 0.f; };
    extern RgbState rgbEspBox, rgbEspSnaplines, rgbEspFill, rgbEspHeadCircle, rgbCrosshair;
    extern RgbState rgbAimbotFov, rgbSharedVisual;
    extern float aimbotFovThickness;

    // Aimbot
    extern bool   aimbotEnabled;
    extern float  aimbotFov, aimbotSmooth;
    extern int    aimbotTarget;
    extern bool   aimbotWorkOnlyShooting;
    extern bool   aimbotShowWhereToAim;
    extern ImVec4 colAimbotFov;
    extern int    aimbotBindKey;
    extern int    aimbotBindMode;

    // Settings
    extern bool   overlayMode;
    extern int language;
    extern ImVec4 colMenuAccent;

    extern bool   unloadRequested;

    void Draw();
    void DrawKeybinds();
    void DrawAimbotStatus();
    void TickRgbAlways();
    const char* GetKeyName(int keyCode);
}
