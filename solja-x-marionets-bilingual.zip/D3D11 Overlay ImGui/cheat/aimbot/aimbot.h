#pragma once
#include <Windows.h>
#include <string>
#include "../../str.hpp"

enum KeybindMode {
    Switch = 0,
    Tap = 1
};

namespace Aimbot {
    // Basic settings
    extern bool enabled;
    extern bool showFov;
    extern float fov;
    extern int bindKey;
    extern KeybindMode bindMode;
    extern bool useBind;   // если true -> требуется бинда для активации
    extern bool bindActive; // текущее состояние бинда (hold или toggled)

    // Aiming settings
    extern float smooth;
    extern int targetMode; // 0=HEAD, 1=NECK, 2=CHEST
    extern bool workOnlyShooting; // Work only when shooting
    extern bool showWhereToAim;   // Show point on current target

    // Target data
    extern Vector2 bestTarget;
    extern float bestDist;
    extern Vector2 lastTargetPos;
    extern int aimPoint;
    extern bool aimActive;
    extern bool isShooting; // Track shooting state

    void Initialize();
    void Update();
    bool IsActive();

    // Сбрасывает внутреннее состояние бинда (нужно, если пользователь поменял bindKey)
    void ResetBind();

    // Утилита: получить читаемое имя бинда (например "A" или "LMB")
    std::string GetBindName(int vk);

    // Сохранение/загрузка конфигурации (простая реализация)
    bool SaveConfig(const std::string& path);
    bool LoadConfig(const std::string& path);
}
