#include "aimbot.h"
#include <math.h>
#include <Windows.h>
#include <cfloat>
#include <string>
#include <fstream>
#include <sstream>

namespace Aimbot {
    bool enabled = false;
    bool showFov = true;
    float fov = 90.0f;
    int bindKey = VK_LBUTTON;
    KeybindMode bindMode = Switch;
    bool useBind = false; // по умолчанию не требуем бинда
    bool bindActive = false; // текущее состояние активации по бинду

    // Вынесем флаг отслеживания фронта на уровень пространства имён,
    // чтобы ResetBind() мог его сбросить.
    bool bindKeyWasPressed = false;

    float smooth = 5.0f;
    int targetMode = 0; // 0=HEAD, 1=NECK, 2=CHEST
    bool workOnlyShooting = false;
    bool showWhereToAim = false;

    Vector2 bestTarget = { 0.0f, 0.0f };
    float bestDist = FLT_MAX;
    Vector2 lastTargetPos = { 0.0f, 0.0f };
    int aimPoint = 0;
    bool aimActive = false;
    bool isShooting = false;

    void Initialize() {
        enabled = false;
        showFov = true;
        fov = 90.0f;
        bindKey = VK_LBUTTON;
        bindMode = Switch;
        useBind = false;
        bindActive = false;
        bindKeyWasPressed = false;
        smooth = 5.0f;
        targetMode = 0;
        workOnlyShooting = false;
        showWhereToAim = false;
        bestTarget = { 0.0f, 0.0f };
        bestDist = FLT_MAX;
        aimPoint = 0;
        aimActive = false;
        isShooting = false;
    }

    void Update() {
        // Обновляем состояние стрельбы
        isShooting = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;

        // Обновляем состояние бинда (bindActive)
        if (useBind) {
            if (bindMode == Switch) {
                // Hold: bindActive = удержание
                bindActive = (GetAsyncKeyState(bindKey) & 0x8000) != 0;
            } else { // Tap (toggle)
                bool keyPressed = (GetAsyncKeyState(bindKey) & 0x8000) != 0;
                if (keyPressed && !bindKeyWasPressed) {
                    // По фронту переключаем bindActive
                    bindActive = !bindActive;
                }
                bindKeyWasPressed = keyPressed;
            }
        } else {
            // Если бинды не используются — всегда активен
            bindActive = true;
            // Также сбросим флаг фронта, чтобы предотвращать неожиданные переключения при включении useBind
            bindKeyWasPressed = false;
        }
    }

    bool IsActive() {
        return enabled && (!useBind || bindActive);
    }

    void ResetBind() {
        // Состояние бина отдельно от master-переключателя Enable Aimbot.
        bindActive = !useBind;
        bindKeyWasPressed = (GetAsyncKeyState(bindKey) & 0x8000) != 0;
    }

    std::string GetBindName(int vk) {
        if (vk == 0) return std::string("None");
        // Короткие имена для мыши
        if (vk == VK_LBUTTON) return std::string("LMB");
        if (vk == VK_RBUTTON) return std::string("RMB");
        if (vk == VK_MBUTTON) return std::string("MMB");
        if (vk == VK_XBUTTON1) return std::string("X1");
        if (vk == VK_XBUTTON2) return std::string("X2");

        UINT scan = MapVirtualKeyA(vk, MAPVK_VK_TO_VSC);
        char buf[64] = { 0 };
        LONG lParam = (scan << 16);
        if (GetKeyNameTextA(lParam, buf, (int)sizeof(buf))) {
            return std::string(buf);
        }
        char tmp[16];
        sprintf_s(tmp, "VK_%02X", vk & 0xFF);
        return std::string(tmp);
    }

    // Простейшая сериализация: key=value в текстовый файл
    bool SaveConfig(const std::string& path) {
        std::ofstream f(path);
        if (!f.is_open()) return false;
        f << "enabled=" << (enabled ? 1 : 0) << "\n";
        f << "useBind=" << (useBind ? 1 : 0) << "\n";
        f << "bindKey=" << bindKey << "\n";
        f << "bindMode=" << (bindMode==Switch ? 0 : 1) << "\n";
        f << "fov=" << fov << "\n";
        f << "smooth=" << smooth << "\n";
        f << "workOnlyShooting=" << (workOnlyShooting ? 1 : 0) << "\n";
        f << "showWhereToAim=" << (showWhereToAim ? 1 : 0) << "\n";
        f.close();
        return true;
    }

    bool LoadConfig(const std::string& path) {
        std::ifstream f(path);
        if (!f.is_open()) return false;
        std::string line;
        while (std::getline(f, line)) {
            std::istringstream ss(line);
            std::string key;
            if (!std::getline(ss, key, '=')) continue;
            std::string val;
            if (!std::getline(ss, val)) continue;
            if (key == "enabled") enabled = (std::stoi(val) != 0);
            else if (key == "useBind") useBind = (std::stoi(val) != 0);
            else if (key == "bindKey") bindKey = std::stoi(val);
            else if (key == "bindMode") bindMode = (std::stoi(val) == 0 ? Switch : Tap);
            else if (key == "fov") fov = std::stof(val);
            else if (key == "smooth") smooth = std::stof(val);
            else if (key == "workOnlyShooting") workOnlyShooting = (std::stoi(val) != 0);
            else if (key == "showWhereToAim") showWhereToAim = (std::stoi(val) != 0);
        }
        f.close();
        // Сбросим внутреннее состояние бинда после загрузки
        ResetBind();
        return true;
    }
}
