#pragma once
#include <Windows.h>
#include <string>

namespace Hitsound {
    extern bool enabled;

    void Initialize();
    void PlayHitsound();
}
