#include "hitsound.h"
#include <filesystem>
#include <thread>
#include <chrono>

namespace Hitsound {
    bool enabled = true;
    static auto lastHitsoundTime = std::chrono::high_resolution_clock::now();

    void Initialize() {
        namespace fs = std::filesystem;
        
        // Create C:\$ folder if not exists
        std::string basePath = "C:\\$";
        if (!fs::exists(basePath)) {
            try {
                fs::create_directories(basePath);
            }
            catch (...) {
                return;
            }
        }

        // Create C:\$\sounds folder if not exists
        std::string soundsPath = basePath + "\\sounds";
        if (!fs::exists(soundsPath)) {
            try {
                fs::create_directories(soundsPath);
            }
            catch (...) {
                return;
            }
        }
    }

    void PlayHitsound() {
        if (!enabled) return;

        // Check cooldown (0.5 seconds)
        auto now = std::chrono::high_resolution_clock::now();
        auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastHitsoundTime).count();
        
        if (elapsedMs < 500) {
            return;
        }

        lastHitsoundTime = now;

        // Play sound in separate thread with 0.2 second delay
        std::thread([](void) {
            std::this_thread::sleep_for(std::chrono::milliseconds(200));

            namespace fs = std::filesystem;
            std::string soundsPath = "C:\\$\\sounds\\";

            // Try hitsound.wav first
            std::string wavFile = soundsPath + "hitsound.wav";
            if (fs::exists(wavFile)) {
                // Use unique alias to avoid conflicts
                static int wavCounter = 0;
                std::string alias = "waveout_" + std::to_string(wavCounter++);
                
                std::string openCmd = "open \"" + wavFile + "\" type waveaudio alias " + alias;
                mciSendStringA(openCmd.c_str(), NULL, 0, NULL);
                mciSendStringA(("set " + alias + " volume to 400").c_str(), NULL, 0, NULL);  // 40% volume
                mciSendStringA(("play " + alias).c_str(), NULL, 0, NULL);
                std::this_thread::sleep_for(std::chrono::milliseconds(500));  // Wait for sound to play
                mciSendStringA(("close " + alias).c_str(), NULL, 0, NULL);
                return;
            }

            // Try hitsound.mp3 if wav not found
            std::string mp3File = soundsPath + "hitsound.mp3";
            if (fs::exists(mp3File)) {
                // Use unique alias to avoid conflicts
                static int mp3Counter = 0;
                std::string alias = "mp3sound_" + std::to_string(mp3Counter++);
                
                std::string openCmd = "open \"" + mp3File + "\" type mpegvideo alias " + alias;
                mciSendStringA(openCmd.c_str(), NULL, 0, NULL);
                mciSendStringA(("set " + alias + " volume to 400").c_str(), NULL, 0, NULL);  // 40% volume
                mciSendStringA(("play " + alias).c_str(), NULL, 0, NULL);
                std::this_thread::sleep_for(std::chrono::milliseconds(500));  // Wait for sound to play
                mciSendStringA(("close " + alias).c_str(), NULL, 0, NULL);
                return;
            }
        }).detach();
    }
}
