#pragma once
#include <Windows.h>
#include <chrono>
#include <vector>

struct BoxCoordinates
{
    float left;
    float top;
    float right;
    float bottom;
};

enum class TriggerBindMode
{
    Hold = 0,
    Toggle = 1
};

class Trigger
{
public:
    bool triggerBot = true;
    bool useBind = true;
    int bindKey = VK_XBUTTON2;
    int delayMs = 80;
    TriggerBindMode bindMode = TriggerBindMode::Hold;
    static Trigger trigger;

    Trigger();
    void UpdateBindState();
    bool IsBindActive() const { return !useBind || bindActive; }
    void HandleTrigger(float left, float top, float right, float bottom);
    void DrawTriggerZone();
    void ClearBoxCoordinates() { boxesList.clear(); }

private:
    bool bindActive = false;
    bool bindKeyWasPressed = false;
    bool bindToggleState = false;
    std::chrono::steady_clock::time_point nextShotAt{};
    std::vector<BoxCoordinates> boxesList;
};