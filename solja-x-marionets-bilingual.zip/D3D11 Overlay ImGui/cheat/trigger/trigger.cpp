#include "trigger.h"
#include <algorithm>
#include <Windows.h>
#include "../hitsound/hitsound.h"
#include "../../ImGui/imgui.h"

Trigger::Trigger() = default;

Trigger Trigger::trigger;

void Trigger::UpdateBindState()
{
    const bool keyDown = bindKey > 0 && (GetAsyncKeyState(bindKey) & 0x8000) != 0;
    if (!useBind)
    {
        bindActive = true;
        bindKeyWasPressed = keyDown;
        return;
    }

    if (bindMode == TriggerBindMode::Hold)
    {
        bindActive = keyDown;
    }
    else
    {
        if (keyDown && !bindKeyWasPressed)
            bindToggleState = !bindToggleState;
        bindActive = bindToggleState;
    }

    bindKeyWasPressed = keyDown;
}

void Trigger::HandleTrigger(float left, float top, float right, float bottom)
{
    if (!triggerBot)
        return;

    UpdateBindState();
    boxesList.push_back({ left, top, right, bottom });
    if (!IsBindActive())
        return;

    static const int screenCenterX = GetSystemMetrics(SM_CXSCREEN) / 2;
    static const int screenCenterY = GetSystemMetrics(SM_CYSCREEN) / 2;

    const float boxCenterX = (left + right) / 2.0f;
    const float boxWidth = right - left;
    const float toleranceX = (boxWidth / 2.0f) * 0.35f;
    const float boxHeight = bottom - top;
    const float triggerTop = top + boxHeight * 0.1f;
    const float triggerBottom = bottom - boxHeight * 0.04f;

    const bool crosshairOnCenterX = screenCenterX >= boxCenterX - toleranceX && screenCenterX <= boxCenterX + toleranceX;
    const bool crosshairOnBoxY = screenCenterY >= triggerTop && screenCenterY <= triggerBottom;
    if (!crosshairOnCenterX || !crosshairOnBoxY)
        return;

    const auto now = std::chrono::steady_clock::now();
    if (now < nextShotAt)
        return;

    INPUT input[2] = {};
    input[0].type = INPUT_MOUSE;
    input[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
    input[1].type = INPUT_MOUSE;
    input[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;
    SendInput(2, input, sizeof(INPUT));
    Hitsound::PlayHitsound();
    nextShotAt = now + std::chrono::milliseconds((std::max)(0, delayMs));
}

void Trigger::DrawTriggerZone()
{
    UpdateBindState();
    if (!triggerBot || !IsBindActive() || boxesList.empty())
        return;

    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    for (const auto& box : boxesList)
    {
        const float boxCenterX = (box.left + box.right) / 2.0f;
        const float toleranceX = ((box.right - box.left) / 2.0f) * 0.35f;
        const float boxHeight = box.bottom - box.top;
        const float top = box.top + boxHeight * 0.1f;
        const float bottom = box.bottom - boxHeight * 0.04f;
        draw->AddRect(ImVec2(boxCenterX - toleranceX, top),
            ImVec2(boxCenterX + toleranceX, bottom),
            IM_COL32(255, 255, 255, 255), 0.0f, 0, 1.5f);
    }
}