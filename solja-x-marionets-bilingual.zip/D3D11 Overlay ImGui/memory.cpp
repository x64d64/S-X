#include "memory.h"

const char playerpattern[] = {
    0x00, 0x00, 0x80, 0x3F, 0x00, 0x00, 0x80, 0x3F,
    0x00, 0x00, 0x80, 0x3F, 0x80, 0x96, 0x18, 0x4B,
    0x00, 0x00, 0x00, 0x00, 0xCD, 0xCC
};

std::vector<uintptr_t> poslist;
uintptr_t mtxpointer_addr = 0;
std::mutex data_mutex;

bool memcmpv2(const char* a, const char* b, int c) {
    for (int i = 0; i < c; i++)
        if (a[i] != b[i]) return false;
    return true;
}

DWORD GetProcessIdByName(const std::wstring& processName) {
    PROCESSENTRY32W processInfo;
    processInfo.dwSize = sizeof(processInfo);

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
    if (snapshot == INVALID_HANDLE_VALUE) return 0;

    if (!Process32FirstW(snapshot, &processInfo)) {
        CloseHandle(snapshot);
        return 0;
    }

    do {
        if (_wcsicmp(processInfo.szExeFile, processName.c_str()) == 0) {
            CloseHandle(snapshot);
            return processInfo.th32ProcessID;
        }
    } while (Process32NextW(snapshot, &processInfo));

    CloseHandle(snapshot);
    return 0;
}

void MemoryScan(HANDLE hProcess) {
    while (hProcess) {
        std::vector<uintptr_t> temp_poslist;
        uintptr_t temp_mtxpointer_addr = 0;

        uintptr_t address = 0;
        MEMORY_BASIC_INFORMATION64 mm;

        while (VirtualQueryEx(hProcess, (LPCVOID)address, (PMEMORY_BASIC_INFORMATION)&mm, sizeof(mm))) {
            if (mm.Protect == PAGE_READWRITE && mm.State == MEM_COMMIT && mm.Type == MEM_PRIVATE &&
                (uintptr_t)mm.BaseAddress < 0x2FFFFFFFF && mm.RegionSize == 2097152) {

                char* buffer = new (std::nothrow) char[mm.RegionSize];
                if (!buffer) {
                    address = (uintptr_t)mm.BaseAddress + mm.RegionSize;
                    continue;
                }

                SIZE_T bytesRead = 0;
                if (ReadProcessMemory(hProcess, (void*)mm.BaseAddress, buffer, mm.RegionSize, &bytesRead)) {
                    for (uintptr_t curadd_offset = 0; curadd_offset < bytesRead; curadd_offset += 4) {
                        uintptr_t curadd_in_buffer = (uintptr_t)buffer + curadd_offset;
                        uintptr_t curadd_in_process = (uintptr_t)mm.BaseAddress + curadd_offset;

                        if (curadd_offset + sizeof(playerpattern) <= bytesRead) {
                            if (memcmpv2((char*)curadd_in_buffer, (char*)playerpattern, sizeof(playerpattern))) {
                                uintptr_t poss_addr = curadd_in_process - sizeof(Vector4) * 2;
                                TMatrix checkMatrix;
                                if (ReadProcessMemory(hProcess, (LPCVOID)poss_addr, &checkMatrix, sizeof(TMatrix), NULL)) {
                                    if (checkMatrix.scale.x == 1.f && checkMatrix.rotation.x == 0.f) {
                                        temp_poslist.push_back(poss_addr);
                                    }
                                }
                            }
                        }

                        if (curadd_offset + sizeof(mtx_checker) <= bytesRead) {
                            mtx_checker* checker = (mtx_checker*)curadd_in_buffer;
                            if (checker->isvalid()) {
                                temp_mtxpointer_addr = (curadd_in_process - 0x178 + 0x100);
                                c_matrix test_mtx;
                                if (!ReadProcessMemory(hProcess, (LPCVOID)temp_mtxpointer_addr, &test_mtx, sizeof(c_matrix), NULL)) {
                                    temp_mtxpointer_addr = 0;
                                }
                            }
                        }
                    }
                }
                delete[] buffer;
            }

            address = (uintptr_t)mm.BaseAddress + mm.RegionSize;
            if (mm.RegionSize == 0) break;
        }

        {
            std::lock_guard<std::mutex> lock(data_mutex);
            if (!temp_poslist.empty()) poslist = std::move(temp_poslist);
            if (temp_mtxpointer_addr != 0) mtxpointer_addr = temp_mtxpointer_addr;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
}
