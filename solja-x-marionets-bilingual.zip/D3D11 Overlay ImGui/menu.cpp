﻿#include "Menu.h"
#include "ImGui/imgui.h"
#include "cheat/aimbot/aimbot.h"
#include "cheat/trigger/trigger.h"
#include "config_system.h"
#include "loader.h"
#include <Windows.h>
#include <vector>
#include <string>
#include <sstream>
#include <unordered_map>
#include <cstring>
#include <TlHelp32.h>
#include <thread>

namespace Menu
{
    static const char* Tr(const char* text);
    // --- ESP ---
    bool espBox = false;
    bool espSnaplines = false;
    bool espFill = false;
    bool espHeadCircle = false;
    bool customCrosshair = false;

    ImVec4 colEspBox = ImVec4(1.f, 1.f, 1.f, 1.f);
    ImVec4 colEspSnaplines = ImVec4(0.f, 1.f, 0.f, 1.f);
    ImVec4 colEspFill = ImVec4(1.f, 1.f, 1.f, 0.2f);
    ImVec4 colEspHeadCircle = ImVec4(0.f, 1.f, 1.f, 1.f);
    ImVec4 colCrosshair = ImVec4(1.f, 0.f, 0.f, 1.f);

    int boxMode = 1;
    float espLineThickness = 1.0f;
    int snaplineMode = 0;
    float fillAlpha = 0.2f;
    float snaplineOpacity = 0.75f;

    int crosshairMode = 1;
    float crosshairSize = 7.0f;
    float crosshairGap = 3.0f;
    float crosshairThickness = 1.0f;
    bool useSharedVisualColor = true;
    ImVec4 colSharedVisual = ImVec4(0.24f, 0.72f, 0.72f, 1.0f);
    RgbState rgbSharedVisual;
    float aimbotFovThickness = 1.0f;
    RgbState rgbEspBox, rgbEspSnaplines, rgbEspFill, rgbEspHeadCircle, rgbCrosshair;
    RgbState rgbAimbotFov;

    // --- Aimbot ---
    bool   aimbotEnabled = false;
    float  aimbotFov = 90.f;
    float  aimbotSmooth = 5.f;
    int    aimbotTarget = 0;
    bool   aimbotWorkOnlyShooting = true;
    bool   aimbotShowWhereToAim = false;
    ImVec4 colAimbotFov = ImVec4(1.f, 0.f, 0.f, 1.f);
    int    aimbotBindKey = VK_XBUTTON2;  // MOUSE5 вместо VK_LBUTTON
    int    aimbotBindMode = 0;

    // --- Settings ---
    bool   overlayMode = false;
    int language = 0;
    static ImVec4 colMenuAccent = ImVec4(0.42f, 0.56f, 0.85f, 1.f);

    bool   unloadRequested = false;

    static bool bindingAimbotKey = false;
    static bool waitingForAimbotBindMouseRelease = false;
    static bool bindingTriggerKey = false;
    static bool waitingForTriggerBindMouseRelease = false;
    static bool lastAimbotActive = false;
    static float aimbotStatusAlpha = 0.f;
    static float aimbotStatusTime = 0.f;
    static const float STATUS_DISPLAY_TIME = 2.5f;

    const char* GetKeyName(int keyCode)
    {
        switch (keyCode)
        {
            case VK_LBUTTON: return "MOUSE1";
            case VK_RBUTTON: return "MOUSE2";
            case VK_MBUTTON: return "MOUSE3";
            case VK_XBUTTON1: return "MOUSE4";
            case VK_XBUTTON2: return "MOUSE5";
            case VK_BACK: return "BACKSPACE";
            case VK_TAB: return "TAB";
            case VK_RETURN: return "ENTER";
            case VK_SHIFT: return "SHIFT";
            case VK_CONTROL: return "CTRL";
            case VK_MENU: return "ALT";
            case VK_ESCAPE: return "ESC";
            case VK_SPACE: return "SPACE";
            case VK_DELETE: return "DELETE";
            case VK_INSERT: return "INSERT";
            case VK_HOME: return "HOME";
            case VK_END: return "END";
            case VK_LEFT: return "LEFT";
            case VK_RIGHT: return "RIGHT";
            case VK_UP: return "UP";
            case VK_DOWN: return "DOWN";
            case VK_F1: return "F1";
            case VK_F2: return "F2";
            case VK_F3: return "F3";
            case VK_F4: return "F4";
            case VK_F5: return "F5";
            case VK_F6: return "F6";
            case VK_F7: return "F7";
            case VK_F8: return "F8";
            case VK_F9: return "F9";
            case VK_F10: return "F10";
            case VK_F11: return "F11";
            case VK_F12: return "F12";
            case 'A': return "A";
            case 'B': return "B";
            case 'C': return "C";
            case 'D': return "D";
            case 'E': return "E";
            case 'F': return "F";
            case 'G': return "G";
            case 'H': return "H";
            case 'I': return "I";
            case 'J': return "J";
            case 'K': return "K";
            case 'L': return "L";
            case 'M': return "M";
            case 'N': return "N";
            case 'O': return "O";
            case 'P': return "P";
            case 'Q': return "Q";
            case 'R': return "R";
            case 'S': return "S";
            case 'T': return "T";
            case 'U': return "U";
            case 'V': return "V";
            case 'W': return "W";
            case 'X': return "X";
            case 'Y': return "Y";
            case 'Z': return "Z";
            case '0': return "0";
            case '1': return "1";
            case '2': return "2";
            case '3': return "3";
            case '4': return "4";
            case '5': return "5";
            case '6': return "6";
            case '7': return "7";
            case '8': return "8";
            case '9': return "9";
            default: return "UNKNOWN";
        }
    }

    static void ApplySharedVisualPalette();
    void TickRgbAlways()
    {
        auto tickRgbColor = [](RgbState& rgb, ImVec4& col) {
            if (!rgb.enabled) return;
            rgb.hue += ImGui::GetIO().DeltaTime * rgb.speed * 0.2f;
            if (rgb.hue > 1.f) rgb.hue -= 1.f;
            ImGui::ColorConvertHSVtoRGB(rgb.hue, 1.f, 1.f, col.x, col.y, col.z);
        };

        tickRgbColor(rgbEspBox, colEspBox);
        tickRgbColor(rgbEspSnaplines, colEspSnaplines);
        tickRgbColor(rgbEspFill, colEspFill);
        tickRgbColor(rgbEspHeadCircle, colEspHeadCircle);
        tickRgbColor(rgbCrosshair, colCrosshair);
        tickRgbColor(rgbAimbotFov, colAimbotFov);
        tickRgbColor(rgbSharedVisual, colSharedVisual);
        ApplySharedVisualPalette();

        const bool active = Aimbot::IsActive();
        if (active != lastAimbotActive)
        {
            aimbotStatusTime = 0.f;
            aimbotStatusAlpha = 1.f;
            lastAimbotActive = active;
        }

        aimbotStatusTime += ImGui::GetIO().DeltaTime;
        if (aimbotStatusTime < STATUS_DISPLAY_TIME)
        {
            float fadeStart = STATUS_DISPLAY_TIME - 0.5f;
            if (aimbotStatusTime > fadeStart)
            {
                aimbotStatusAlpha = (STATUS_DISPLAY_TIME - aimbotStatusTime) / 0.5f;
            }
            else
            {
                aimbotStatusAlpha = 1.f;
            }
        }
        else
        {
            aimbotStatusAlpha = 0.f;
        }
    }

    void DrawAimbotStatus()
    {
        if (aimbotStatusAlpha <= 0.001f) return;

        ImDrawList* draw = ImGui::GetForegroundDrawList();
        ImVec2 screenSize = ImGui::GetIO().DisplaySize;
        
        const float padding = 20.f;
        ImVec2 bottomRight = ImVec2(screenSize.x - padding, screenSize.y - padding);

        const char* statusText = Aimbot::IsActive() ? "ON" : "OFF";
        ImVec4 statusColor = Aimbot::IsActive() ? ImVec4(0.f, 1.f, 0.f, 1.f) : ImVec4(1.f, 0.f, 0.f, 1.f);
        
        ImVec4 displayColor = statusColor;
        displayColor.w = aimbotStatusAlpha;
        ImU32 statusColorU32 = ImGui::ColorConvertFloat4ToU32(displayColor);

        ImVec2 textSize = ImGui::CalcTextSize(statusText);
        ImVec2 textPos = ImVec2(bottomRight.x - textSize.x, bottomRight.y - textSize.y);

        draw->AddText(textPos, statusColorU32, statusText);
    }

    static void ApplyStyle()
    {
        // Keep Brathack's stock dark palette with its fixed accent color.
        ImGui::StyleColorsDark();
        ImVec4* colors = ImGui::GetStyle().Colors;
        colors[ImGuiCol_CheckMark] = colMenuAccent;
        colors[ImGuiCol_SliderGrab] = colMenuAccent;
        colors[ImGuiCol_SliderGrabActive] = ImVec4(colMenuAccent.x, colMenuAccent.y, colMenuAccent.z, 0.8f);
        colors[ImGuiCol_TabHovered] = ImVec4(colMenuAccent.x, colMenuAccent.y, colMenuAccent.z, 0.7f);
        colors[ImGuiCol_TabActive] = colMenuAccent;
        colors[ImGuiCol_Header] = ImVec4(colMenuAccent.x, colMenuAccent.y, colMenuAccent.z, 0.25f);
        colors[ImGuiCol_HeaderHovered] = ImVec4(colMenuAccent.x, colMenuAccent.y, colMenuAccent.z, 0.4f);
        colors[ImGuiCol_HeaderActive] = ImVec4(colMenuAccent.x, colMenuAccent.y, colMenuAccent.z, 0.6f);
    }

    static const char* Tr(const char* text)
    {
        if (language != 1 || !text) return text;
        static const std::unordered_map<std::string, std::string> ru = {
            {"Aimbot", "Аимбот"}, {"Triggerbot", "Триггербот"}, {"ESP", "ESP"}, {"Config", "Конфиг"}, {"Settings", "Настройки"},
            {"Enable Aimbot", "Включить аимбот"}, {"Use bind", "Использовать бинд"}, {"Bind mode##aimbot", "Режим бинда##aimbot"}, {"Hold", "Удержание"}, {"Toggle", "Переключение"},
            {"Press a key...", "Нажмите клавишу..."}, {"BIND##aimbotbind", "БИНД##aimbotbind"}, {"BIND##triggerbind", "БИНД##triggerbind"}, {"Press a key...##triggerbind", "Нажмите клавишу...##triggerbind"},
            {"FOV", "FOV"}, {"FOV opacity", "Прозрачность FOV"}, {"FOV line", "Толщина FOV"}, {"Smooth", "Плавность"}, {"Target:", "Цель:"}, {"Head##tgt", "Голова##tgt"}, {"Neck##tgt", "Шея##tgt"}, {"Chest##tgt", "Грудь##tgt"},
            {"Show FOV", "Показывать FOV"}, {"Work Only Shooting", "Только при стрельбе"}, {"Show Where To Aim", "Показывать точку прицеливания"},
            {"Enable Triggerbot", "Включить триггербот"}, {"Bind mode", "Режим бинда"}, {"Shot delay (ms)", "Задержка выстрела (мс)"}, {"0 ms##triggerdelay", "0 мс##triggerdelay"}, {"Instant", "Мгновенно"}, {"Status: %s", "Статус: %s"},
            {"Use shared palette", "Общая палитра"}, {"Line width", "Толщина линий"}, {"ESP Box", "Бокс ESP"}, {"Box##boxbtn", "Бокс##boxbtn"}, {"Corner##boxbtn", "Углы##boxbtn"}, {"3D##boxbtn", "3D##boxbtn"},
            {"ESP Snaplines", "Линии ESP"}, {"Bottom", "Снизу"}, {"Top", "Сверху"}, {"Anchor##snap", "Начало линии##snap"}, {"Opacity##snap", "Прозрачность##snap"},
            {"ESP Fill", "Заливка ESP"}, {"ESP Head Circle", "Круг у головы"}, {"Custom Crosshair", "Свой прицел"}, {"Size", "Размер"}, {"Thickness", "Толщина"}, {"Gap", "Зазор"}, {"Circle##cross", "Круг##cross"}, {"Default##cross", "Классический##cross"}, {"T##cross", "Т-образный##cross"},
            {"Config name", "Имя конфига"}, {"Available configs", "Сохранённые конфиги"}, {"Select config...", "Выберите конфиг..."}, {"Save as", "Сохранить как"}, {"Load selected", "Загрузить выбранный"}, {"Save config", "Сохранить конфиг"}, {"Refresh list", "Обновить список"}, {"No saved configs found.", "Сохранённых конфигов нет."}, {"Startup loads the config named default when it exists.", "При запуске загружается конфиг default, если он существует."},
            {"Settings", "Настройки"}, {"Language", "Язык"}, {"Overlay Mode", "Режим оверлея"}, {"Unload", "Выгрузить"},
            {"rgb mode active", "RGB-режим включён"}, {"rgb", "RGB"}, {"speed##s", "Скорость##s"}, {"Aimbot", "Аимбот"}, {"Triggerbot", "Триггербот"},
            {"Master switch for the aimbot. The bind only controls its active state and does not change this setting.", "Главный переключатель аимбота. Бинд меняет только активность и не выключает эту настройку."},
            {"Choose the keyboard or mouse button that temporarily or persistently activates the aimbot.", "Выберите клавишу или кнопку мыши для активации аимбота."},
            {"When enabled, the bind controls runtime activation. Turning it off leaves the master switch unchanged.", "При включении бинд управляет активацией, не меняя главный переключатель."},
            {"Hold keeps the aimbot active only while the bind is held. Toggle changes active state on each press.", "Удержание работает, пока зажат бинд. Переключение меняет состояние при каждом нажатии."},
            {"Changes the transparency of the FOV circle.", "Меняет прозрачность круга FOV."}, {"Changes the thickness of the FOV circle.", "Меняет толщину круга FOV."}, {"Limits the radius used to select targets.", "Ограничивает радиус выбора цели."},
            {"Controls how quickly the aim point approaches the selected target.", "Задаёт скорость наведения на выбранную цель."}, {"Aims at the head position.", "Наводится на голову."}, {"Aims at the neck position.", "Наводится на шею."}, {"Aims at the chest position.", "Наводится на грудь."},
            {"Draws the configured FOV circle on screen.", "Рисует круг FOV на экране."}, {"Activates aiming only while the fire button is pressed.", "Включает наведение только при нажатии огня."}, {"Displays the current aim point marker.", "Показывает маркер точки наведения."},
            {"Automatically fires when a valid target is under the crosshair.", "Автоматически стреляет, когда цель под прицелом."}, {"Requires the triggerbot bind to be active before it can fire.", "Для стрельбы требуется активный бинд триггербота."}, {"Assign the key used to activate the triggerbot.", "Назначает клавишу активации триггербота."},
            {"Hold requires keeping the bind pressed; Toggle switches its active state on each press.", "Удержание действует, пока нажат бинд; переключение меняет состояние при каждом нажатии."}, {"Sets the delay before the triggerbot fires.", "Задаёт задержку перед выстрелом."}, {"Sets the trigger delay to zero milliseconds.", "Устанавливает задержку в ноль миллисекунд."},
            {"Uses one color for the ESP elements below.", "Использует один цвет для элементов ESP ниже."}, {"Sets the thickness of ESP outlines and lines.", "Задаёт толщину линий и рамок ESP."}, {"Draws a 2D, corner, or 3D outline around each player.", "Рисует 2D-, угловую или 3D-рамку вокруг игрока."}, {"Draws a full rectangular ESP box.", "Рисует полную прямоугольную рамку ESP."}, {"Draws only the corners of the ESP box.", "Рисует только углы рамки ESP."}, {"Draws a perspective 3D box.", "Рисует перспективную 3D-рамку."},
            {"Draws a line from the selected screen edge to each player.", "Рисует линию от выбранного края экрана к игроку."}, {"Chooses whether snaplines begin at the top or bottom of the screen.", "Выбирает край экрана, откуда начинаются линии."}, {"Adjusts snapline transparency.", "Меняет прозрачность линий."}, {"Adds a translucent fill inside each ESP box.", "Добавляет полупрозрачную заливку в рамку ESP."}, {"Adjusts the fill transparency.", "Меняет прозрачность заливки."},
            {"Draws a marker around the head position.", "Рисует маркер вокруг головы."}, {"Replaces the default crosshair with the selected shape and size.", "Заменяет стандартный прицел выбранной формой и размером."}, {"Sets the crosshair size.", "Задаёт размер прицела."}, {"Sets the crosshair line thickness.", "Задаёт толщину линий прицела."}, {"Sets the gap around the crosshair center.", "Задаёт зазор в центре прицела."}, {"Uses a circular crosshair.", "Использует круглый прицел."}, {"Uses a four-part crosshair.", "Использует классический прицел из четырёх линий."}, {"Uses a T-shaped crosshair.", "Использует Т-образный прицел."},
            {"Changes whether the overlay captures mouse input while its menu is visible.", "Включает или отключает захват мыши оверлеем при открытом меню."},
            {"Binds", "Бинды"}, {"Select a config or enter a name to save.", "Выберите конфиг или введите имя для сохранения."}, {"Select config...", "Выбрать конфиг..."}, {"Select a config first.", "Сначала выберите конфиг."},
            {"No configs yet. Save one to create it.", "Конфигов пока нет. Сохраните конфиг, чтобы создать его."}, {"Could not read the config folder.", "Не удалось прочитать папку конфигов."}, {"APPDATA path is unavailable.", "Папка APPDATA недоступна."},
            {"Config name must contain 1 to 32 characters.", "Имя конфига должно содержать от 1 до 32 символов."}, {"Use only letters, digits, spaces, _ and -.", "Используйте только буквы, цифры, пробел, _ и -."}, {"Could not write config file.", "Не удалось записать файл конфига."},
            {"Config write failed.", "Ошибка записи конфига."}, {"Config is empty or invalid.", "Конфиг пустой или повреждён."}, {"Saved config: ", "Сохранён конфиг: "}, {"Loaded config: ", "Загружен конфиг: "}, {"Config not found: ", "Конфиг не найден: "}, {" config(s) found.", " конфиг(ов) найдено."}, {"active", "активен"}, {"waiting for bind", "ожидание бинда"}
        };
        const auto it = ru.find(text);
        return it == ru.end() ? text : it->second.c_str();
    }
    static const char* TrConfigStatus(const std::string& status)
    {
        static std::string translated;
        if (language != 1) return status.c_str();
        const char* prefixes[] = { "Saved config: ", "Loaded config: ", "Config not found: " };
        for (const char* prefix : prefixes)
        {
            const size_t n = strlen(prefix);
            if (status.compare(0, n, prefix) == 0)
            {
                translated = Tr(prefix) + status.substr(n);
                return translated.c_str();
            }
        }
        translated = Tr(status.c_str());
        return translated.c_str();
    }

    static void ItemTooltip(const char* description)
    {
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("%s", Tr(description));
    }
    static void TickRgb(RgbState& rgb, ImVec4& col)
    {
        if (!rgb.enabled) return;
        rgb.hue += ImGui::GetIO().DeltaTime * rgb.speed * 0.2f;
        if (rgb.hue > 1.f) rgb.hue -= 1.f;
        ImGui::ColorConvertHSVtoRGB(rgb.hue, 1.f, 1.f, col.x, col.y, col.z);
    }

    static void ColorPickerButton(const char* id, ImVec4& col, RgbState& rgb)
    {
        ImGui::SameLine();
        ImGui::PushID(id);

        ImGui::ColorButton("##cb", col,
            ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoBorder,
            ImVec2(16, 16));

        if (ImGui::IsItemClicked())
            ImGui::OpenPopup("cpop");

        if (ImGui::BeginPopup("cpop"))
        {
            if (!rgb.enabled)
                ImGui::ColorPicker4("##cp", (float*)&col,
                    ImGuiColorEditFlags_AlphaBar |
                    ImGuiColorEditFlags_DisplayRGB |
                    ImGuiColorEditFlags_PickerHueBar);
            else
                ImGui::TextDisabled(Tr("rgb mode active"));

            ImGui::Separator();
            ImGui::Checkbox(Tr("rgb"), &rgb.enabled);
            if (rgb.enabled)
            {
                ImGui::SetNextItemWidth(180);
                ImGui::SliderFloat(Tr("speed##s"), &rgb.speed, 0.1f, 10.f, "%.1f");
            }
            ImGui::EndPopup();
        }

        ImGui::PopID();
    }

    void DrawKeybinds()
    {
        Trigger::trigger.UpdateBindState();
        struct BindRow { const char* label; std::string key; bool active; };
        std::vector<BindRow> rows;
        if (Aimbot::enabled)
            rows.push_back({ Tr("Aimbot"), Aimbot::GetBindName(aimbotBindKey), Aimbot::IsActive() });
        if (Trigger::trigger.triggerBot)
            rows.push_back({ Tr("Triggerbot"), Aimbot::GetBindName(Trigger::trigger.bindKey), Trigger::trigger.IsBindActive() });
        if (rows.empty())
            return;

        ImDrawList* draw = ImGui::GetForegroundDrawList();
        const ImVec2 pos(48.0f, 18.0f);
        constexpr float width = 182.0f;
        constexpr float headerHeight = 25.0f;
        constexpr float rowHeight = 27.0f;
        const float totalHeight = headerHeight + rowHeight * static_cast<float>(rows.size());
        const ImU32 panelBg = IM_COL32(8, 9, 10, 238);
        const ImU32 headerBg = IM_COL32(13, 14, 16, 248);
        const ImU32 rowBg = IM_COL32(20, 32, 33, 242);
        const ImU32 accent = IM_COL32(42, 194, 181, 255);

        draw->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + totalHeight), panelBg);
        draw->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + headerHeight), headerBg);
        draw->AddText(ImVec2(pos.x + 10.0f, pos.y + 6.0f), IM_COL32(235, 237, 238, 255), Tr("Binds"));
        draw->AddLine(ImVec2(pos.x, pos.y + headerHeight), ImVec2(pos.x + width, pos.y + headerHeight), accent, 1.5f);

        for (size_t i = 0; i < rows.size(); ++i)
        {
            const float rowTop = pos.y + headerHeight + rowHeight * static_cast<float>(i);
            const float rowCenterY = rowTop + rowHeight * 0.5f;
            const ImU32 stateColor = rows[i].active ? accent : IM_COL32(105, 112, 114, 255);
            draw->AddRectFilled(ImVec2(pos.x, rowTop + 1.5f), ImVec2(pos.x + width, rowTop + rowHeight), rowBg);
            draw->AddCircleFilled(ImVec2(pos.x + 11.0f, rowCenterY), 3.0f, stateColor);
            draw->AddText(ImVec2(pos.x + 21.0f, rowCenterY - ImGui::GetFontSize() * 0.5f), IM_COL32(220, 223, 224, 255), rows[i].label);
            const ImVec2 keySize = ImGui::CalcTextSize(rows[i].key.c_str());
            draw->AddText(ImVec2(pos.x + width - keySize.x - 9.0f, rowCenterY - ImGui::GetFontSize() * 0.5f), IM_COL32(165, 173, 174, 255), rows[i].key.c_str());
        }
    }
    static void ApplySharedVisualPalette()
    {
        if (!useSharedVisualColor)
            return;
        colEspBox = colSharedVisual;
        colEspSnaplines = colSharedVisual;
        colEspSnaplines.w = snaplineOpacity;
        colEspFill = colSharedVisual;
        colEspFill.w = fillAlpha;
        colEspHeadCircle = colSharedVisual;
        colCrosshair = colSharedVisual;
    }
    void Draw()
    {
        TickRgb(rgbEspBox, colEspBox);
        TickRgb(rgbEspSnaplines, colEspSnaplines);
        TickRgb(rgbEspFill, colEspFill);
        TickRgb(rgbEspHeadCircle, colEspHeadCircle);
        TickRgb(rgbCrosshair, colCrosshair);
        TickRgb(rgbAimbotFov, colAimbotFov);
        TickRgb(rgbSharedVisual, colSharedVisual);
        ApplySharedVisualPalette();

        aimbotEnabled = Aimbot::enabled;

        Aimbot::fov = aimbotFov;
        Aimbot::smooth = aimbotSmooth;
        Aimbot::targetMode = aimbotTarget;
        Aimbot::workOnlyShooting = aimbotWorkOnlyShooting;
        Aimbot::showWhereToAim = aimbotShowWhereToAim;
        Aimbot::bindKey = aimbotBindKey;
        Aimbot::bindMode = (KeybindMode)aimbotBindMode;

        ApplyStyle();

        ImGui::SetNextWindowSize(ImVec2(550, 400), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowBgAlpha(0.95f);
        ImGui::Begin("solja x marionets <3", nullptr, ImGuiWindowFlags_NoScrollbar);
        if (ImGui::BeginTabBar("##tabs", ImGuiTabBarFlags_NoTabListScrollingButtons))
        {
            if (ImGui::BeginTabItem(Tr("Aimbot")))
            {
                ImGui::Spacing();
                
                ImGui::Checkbox(Tr("Enable Aimbot"), &aimbotEnabled);
                ItemTooltip("Master switch for the aimbot. The bind only controls its active state and does not change this setting.");
                if (aimbotEnabled != Aimbot::enabled)
                    Aimbot::enabled = aimbotEnabled;
                
                ImGui::SameLine();
                const bool clickedAimbotBind = ImGui::Button(Tr("BIND##aimbotbind"), ImVec2(50, 0));
                ItemTooltip("Choose the keyboard or mouse button that temporarily or persistently activates the aimbot.");
                if (clickedAimbotBind) {
                    bindingAimbotKey = !bindingAimbotKey;
                    waitingForAimbotBindMouseRelease = bindingAimbotKey;
                }

                if (bindingAimbotKey)
                {
                    ImGui::SameLine();
                ImGui::TextColored(ImVec4(1.f, 0.f, 0.f, 1.f), Tr("Press a key..."));
                    if (waitingForAimbotBindMouseRelease)
                    {
                        if ((GetAsyncKeyState(VK_LBUTTON) & 0x8000) == 0)
                            waitingForAimbotBindMouseRelease = false;
                    }
                    else
                    {
                        for (int i = 0; i < 256; i++)
                        {
                            if (GetAsyncKeyState(i) & 0x8000)
                            {
                                if (i != VK_ESCAPE)
                                {
                                    aimbotBindKey = i;
                                    Aimbot::bindKey = i;
                                    Aimbot::ResetBind();
                                }
                                bindingAimbotKey = false;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    ImGui::SameLine();
                    ImGui::TextDisabled(GetKeyName(aimbotBindKey));
                }

                const bool previousUseBind = Aimbot::useBind;
                ImGui::Checkbox(Tr("Use bind"), &Aimbot::useBind);
                ItemTooltip("When enabled, the bind controls runtime activation. Turning it off leaves the master switch unchanged.");
                if (previousUseBind != Aimbot::useBind)
                    Aimbot::ResetBind();
                const char* aimBindModes[] = { Tr("Hold"), Tr("Toggle") };
                int aimBindMode = Aimbot::bindMode == Tap ? 1 : 0;
                if (ImGui::Combo(Tr("Bind mode##aimbot"), &aimBindMode, aimBindModes, IM_ARRAYSIZE(aimBindModes)))
                {
                    aimbotBindMode = aimBindMode;
                    Aimbot::bindMode = aimBindMode == 1 ? Tap : Switch;
                    Aimbot::ResetBind();
                }
                ItemTooltip("Hold keeps the aimbot active only while the bind is held. Toggle changes active state on each press.");

                if (aimbotEnabled)
                {
                    ImGui::Spacing();
                    
                    ImGui::Text(Tr("FOV"));
                    ColorPickerButton("cp_fov", colAimbotFov, rgbAimbotFov);
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat(Tr("FOV opacity"), &colAimbotFov.w, 0.1f, 1.0f, "%.0f%%");
                    ItemTooltip("Changes the transparency of the FOV circle.");
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat(Tr("FOV line"), &aimbotFovThickness, 0.5f, 2.5f, "%.1f px");
                    ItemTooltip("Changes the thickness of the FOV circle.");
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat(Tr("##fov"), &aimbotFov, 1.f, 360.f, "%.0f");
                    ItemTooltip("Limits the radius used to select targets.");

                    ImGui::Spacing();
                    ImGui::Text(Tr("Smooth"));
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat(Tr("##smooth"), &aimbotSmooth, 0.1f, 20.f, "%.1f");
                    ItemTooltip("Controls how quickly the aim point approaches the selected target.");
                    
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();
                    
                    ImGui::Text(Tr("Target:"));
                    float btnWidth = (ImGui::GetContentRegionAvail().x - 8) / 3;
                    if (ImGui::Button(Tr("Head##tgt"), ImVec2(btnWidth, 20)))
                        aimbotTarget = 0;
                    ItemTooltip("Aims at the head position.");
                    ImGui::SameLine();
                    if (ImGui::Button(Tr("Neck##tgt"), ImVec2(btnWidth, 20)))
                        aimbotTarget = 1;
                    ItemTooltip("Aims at the neck position.");
                    ImGui::SameLine();
                    if (ImGui::Button(Tr("Chest##tgt"), ImVec2(btnWidth, 20)))
                        aimbotTarget = 2;
                    ItemTooltip("Aims at the chest position.");
                    
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();
                    
                    ImGui::Checkbox(Tr("Show FOV"), &Aimbot::showFov);
                    ItemTooltip("Draws the configured FOV circle on screen.");
                    ImGui::Checkbox(Tr("Work Only Shooting"), &aimbotWorkOnlyShooting);
                    ItemTooltip("Activates aiming only while the fire button is pressed.");
                    ImGui::Checkbox(Tr("Show Where To Aim"), &aimbotShowWhereToAim);
                    ItemTooltip("Displays the current aim point marker.");
                }

                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem(Tr("Triggerbot")))
            {
                ImGui::Spacing();
                ImGui::Checkbox(Tr("Enable Triggerbot"), &Trigger::trigger.triggerBot);
                ItemTooltip("Automatically fires when a valid target is under the crosshair.");
                ImGui::Checkbox(Tr("Use bind"), &Trigger::trigger.useBind);
                ItemTooltip("Requires the triggerbot bind to be active before it can fire.");

                ImGui::Spacing();
                if (ImGui::Button(Tr(bindingTriggerKey ? "Press a key...##triggerbind" : "BIND##triggerbind"), ImVec2(90, 0)))
                {
                    bindingTriggerKey = true;
                    waitingForTriggerBindMouseRelease = true;
                }
                ItemTooltip("Assign the key used to activate the triggerbot.");
                ImGui::SameLine();
                ImGui::TextDisabled(Aimbot::GetBindName(Trigger::trigger.bindKey).c_str());

                if (bindingTriggerKey)
                {
                    if (waitingForTriggerBindMouseRelease)
                    {
                        if ((GetAsyncKeyState(VK_LBUTTON) & 0x8000) == 0)
                            waitingForTriggerBindMouseRelease = false;
                    }
                    else
                    {
                        for (int key = 1; key < 256; ++key)
                        {
                            if ((GetAsyncKeyState(key) & 0x8000) == 0)
                                continue;
                            if (key == VK_ESCAPE)
                                bindingTriggerKey = false;
                            else
                            {
                                Trigger::trigger.bindKey = key;
                                Trigger::trigger.UpdateBindState();
                                bindingTriggerKey = false;
                            }
                            break;
                        }
                    }
                }

                const char* triggerModes[] = { Tr("Hold"), Tr("Toggle") };
                int triggerMode = Trigger::trigger.bindMode == TriggerBindMode::Toggle ? 1 : 0;
                if (ImGui::Combo(Tr("Bind mode"), &triggerMode, triggerModes, IM_ARRAYSIZE(triggerModes)))
                {
                    Trigger::trigger.bindMode = triggerMode == 1 ? TriggerBindMode::Toggle : TriggerBindMode::Hold;
                    Trigger::trigger.UpdateBindState();
                }
                ItemTooltip("Hold requires keeping the bind pressed; Toggle switches its active state on each press.");
                ImGui::SliderInt(Tr("Shot delay (ms)"), &Trigger::trigger.delayMs, 0, 500);
                ItemTooltip("Sets the delay before the triggerbot fires.");
                if (ImGui::Button(Tr("0 ms##triggerdelay")))
                    Trigger::trigger.delayMs = 0;
                ItemTooltip("Sets the trigger delay to zero milliseconds.");
                ImGui::SameLine();
                ImGui::TextDisabled(Tr("Instant"));
                ImGui::TextDisabled(Tr("Status: %s"), Trigger::trigger.IsBindActive() ? Tr("active") : Tr("waiting for bind"));
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem(Tr("ESP")))
            {
                ImGui::Spacing();
                ImGui::Checkbox(Tr("Use shared palette"), &useSharedVisualColor);
                ItemTooltip("Uses one color for the ESP elements below.");
                if (useSharedVisualColor)
                {
                    ColorPickerButton("cp_shared", colSharedVisual, rgbSharedVisual);
                }
                ImGui::SetNextItemWidth(-1);
                ImGui::SliderFloat(Tr("Line width"), &espLineThickness, 0.5f, 2.0f, "%.1f px");
                ItemTooltip("Sets the thickness of ESP outlines and lines.");
                ImGui::Spacing();

                ImGui::Checkbox(Tr("ESP Box"), &espBox);
                ItemTooltip("Draws a 2D, corner, or 3D outline around each player.");
                if (!useSharedVisualColor) ColorPickerButton("cp_box", colEspBox, rgbEspBox);
                if (espBox)
                {
                    ImGui::Indent();
                    float btnWidth = (ImGui::GetContentRegionAvail().x - 8) / 3;
                if (ImGui::Button(Tr("Box##boxbtn"), ImVec2(btnWidth, 20))) boxMode = 0;
                    ItemTooltip("Draws a full rectangular ESP box.");
                    ImGui::SameLine();
                if (ImGui::Button(Tr("Corner##boxbtn"), ImVec2(btnWidth, 20))) boxMode = 1;
                    ItemTooltip("Draws only the corners of the ESP box.");
                    ImGui::SameLine();
                if (ImGui::Button(Tr("3D##boxbtn"), ImVec2(btnWidth, 20))) boxMode = 2;
                    ItemTooltip("Draws a perspective 3D box.");
                    ImGui::Unindent();
                }

                ImGui::Spacing();

                ImGui::Checkbox(Tr("ESP Snaplines"), &espSnaplines);
                ItemTooltip("Draws a line from the selected screen edge to each player.");
                if (!useSharedVisualColor) ColorPickerButton("cp_snap", colEspSnaplines, rgbEspSnaplines);
                if (espSnaplines)
                {
                    const char* snapAnchors[] = { Tr("Bottom"), Tr("Top") };
                    ImGui::SetNextItemWidth(-1);
                    ImGui::Combo(Tr("Anchor##snap"), &snaplineMode, snapAnchors, IM_ARRAYSIZE(snapAnchors));
                    ItemTooltip("Chooses whether snaplines begin at the top or bottom of the screen.");
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat(Tr("Opacity##snap"), &snaplineOpacity, 0.1f, 1.0f, "%.0f%%");
                    ItemTooltip("Adjusts snapline transparency.");
                }

                ImGui::Spacing();

                ImGui::Checkbox(Tr("ESP Fill"), &espFill);
                ItemTooltip("Adds a translucent fill inside each ESP box.");
                if (!useSharedVisualColor) ColorPickerButton("cp_fill", colEspFill, rgbEspFill);
                if (espFill)
                {
                    ImGui::Indent();
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat(Tr("##fillAlpha"), &fillAlpha, 0.0f, 1.0f);
                    ItemTooltip("Adjusts the fill transparency.");
                    ImGui::Unindent();
                }

                ImGui::Spacing();
                ImGui::Spacing();

                ImGui::Checkbox(Tr("ESP Head Circle"), &espHeadCircle);
                ItemTooltip("Draws a marker around the head position.");
                if (!useSharedVisualColor) ColorPickerButton("cp_head", colEspHeadCircle, rgbEspHeadCircle);

                ImGui::Spacing();
                ImGui::Spacing();

                ImGui::Checkbox(Tr("Custom Crosshair"), &customCrosshair);
                ItemTooltip("Replaces the default crosshair with the selected shape and size.");
                if (!useSharedVisualColor) ColorPickerButton("cp_cross", colCrosshair, rgbCrosshair);
                if (customCrosshair)
                {
                    ImGui::Indent();
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat(Tr("Size"), &crosshairSize, 2.0f, 16.0f, "%.0f px");
                    ItemTooltip("Sets the crosshair size.");
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat(Tr("Thickness"), &crosshairThickness, 0.5f, 2.5f, "%.1f px");
                    ItemTooltip("Sets the crosshair line thickness.");
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat(Tr("Gap"), &crosshairGap, 0.0f, 10.0f, "%.0f px");
                    ItemTooltip("Sets the gap around the crosshair center.");
                    float btnWidth = (ImGui::GetContentRegionAvail().x - 8) / 3;
                    if (ImGui::Button(Tr("Circle##cross"), ImVec2(btnWidth, 20))) crosshairMode = 0;
                    ItemTooltip("Uses a circular crosshair.");
                    ImGui::SameLine();
                    if (ImGui::Button(Tr("Default##cross"), ImVec2(btnWidth, 20))) crosshairMode = 1;
                    ItemTooltip("Uses a four-part crosshair.");
                    ImGui::SameLine();
                    if (ImGui::Button(Tr("T##cross"), ImVec2(btnWidth, 20))) crosshairMode = 2;
                    ItemTooltip("Uses a T-shaped crosshair.");
                    ImGui::Unindent();
                }

                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem(Tr("Config")))
            {
                ImGui::Spacing();
                static char configName[64] = "default";
                static std::string selectedConfig;
                static std::string configStatus = "Select a config or enter a name to save.";
                static std::vector<std::string> configNames;
                static bool configListLoaded = false;
                if (!configListLoaded) { ConfigSystem::List(configNames, configStatus); configListLoaded = true; }
                const char* selectedLabel = selectedConfig.empty() ? Tr("Select config...") : selectedConfig.c_str();
                if (ImGui::BeginCombo(Tr("Available configs"), selectedLabel))
                {
                    for (const auto& name : configNames)
                    {
                        const bool selected = selectedConfig == name;
                        if (ImGui::Selectable(name.c_str(), selected))
                        {
                            selectedConfig = name;
                            strcpy_s(configName, sizeof(configName), name.c_str());
                        }
                        if (selected) ImGui::SetItemDefaultFocus();
                    }
                    ImGui::EndCombo();
                }
                if (configNames.empty()) ImGui::TextDisabled(Tr("No saved configs found."));
                ImGui::Text(Tr("Save as"));
                ImGui::SetNextItemWidth(-1);
                ImGui::InputText(Tr("##config_name"), configName, sizeof(configName));
                const float configButtonWidth = (ImGui::GetContentRegionAvail().x - 6.f) * 0.5f;
                if (ImGui::Button(Tr("Load selected"), ImVec2(configButtonWidth, 25.f)))
                {
                    if (selectedConfig.empty()) configStatus = Tr("Select a config first.");
                    else ConfigSystem::Load(selectedConfig, configStatus);
                }
                ImGui::SameLine();
                if (ImGui::Button(Tr("Save config"), ImVec2(-1, 25.f)))
                {
                    if (ConfigSystem::Save(configName, configStatus))
                    {
                        selectedConfig = configName;
                        std::string listMessage;
                        ConfigSystem::List(configNames, listMessage);
                    }
                }
                if (ImGui::Button(Tr("Refresh list"))) { ConfigSystem::List(configNames, configStatus); configListLoaded = true; }
                ImGui::TextWrapped("%s", TrConfigStatus(configStatus));
                ImGui::Spacing();
                ImGui::TextDisabled(Tr("Startup loads the config named default when it exists."));
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem(Tr("Settings")))
            {
                ImGui::Spacing();

                const char* languageOptions[] = { "English", "Русский" };
                ImGui::Combo(Tr("Language"), &language, languageOptions, IM_ARRAYSIZE(languageOptions));
                ImGui::Spacing();

                ImGui::Checkbox(Tr("Overlay Mode"), &overlayMode);
                ItemTooltip("Changes whether the overlay captures mouse input while its menu is visible.");

                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Spacing();

                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Spacing();

                ImGui::SetCursorPosY(ImGui::GetWindowHeight() - 34.f);
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.28f, 0.10f, 0.10f, 1.f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.45f, 0.15f, 0.15f, 1.f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.60f, 0.18f, 0.18f, 1.f));
                if (ImGui::Button(Tr("Unload"), ImVec2(-1, 24)))
                    unloadRequested = true;
                ImGui::PopStyleColor(3);

                ImGui::EndTabItem();
            }

            ImGui::EndTabBar();
        }

        ImGui::End();
    }
}
