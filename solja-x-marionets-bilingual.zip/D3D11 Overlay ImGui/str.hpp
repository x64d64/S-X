﻿#pragma once
#include <stdlib.h>
#include <cmath>
#include <limits> 
#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include <iostream>
#include <windows.h>


inline int screenX = GetSystemMetrics(SM_CXSCREEN);
inline int screenY = GetSystemMetrics(SM_CYSCREEN);

inline bool isfloat(float fl)
{
    int govno = *(int*)&fl;
    return std::abs(govno) > 10000;
}

struct Vector3
{
    float x, y, z;

    Vector3() : x(0), y(0), z(0) {};
    Vector3(float x, float y, float z) : x(x), y(y), z(z) {};

    inline const Vector3& operator+=(float v) { x += v; y += v; y += v; return *this; };
    inline const Vector3& operator-=(float v) { x -= v; y -= v; y -= v; return *this; };
    inline const Vector3& operator*=(float v) { x *= v; y *= v; z *= v; return *this; };
    inline const Vector3& operator/=(float v) { x /= v; y /= v; z /= v; return *this; };
    inline const Vector3& operator+=(Vector3 v) { x += v.x; y += v.y; z += v.z; return *this; };
    inline const Vector3& operator-=(Vector3 v) { x -= v.x; y -= v.y; z -= v.z; return *this; };
    inline const Vector3& operator*=(Vector3 v) { x *= v.x; y *= v.y; z *= v.z; return *this; };
    inline Vector3& operator/=(Vector3 v) { x /= v.x; y /= v.y; z /= v.z; return *this; };

    inline static float Magnitude(Vector3 v);

    inline float magnitude() { return Magnitude(*this); }

    inline static float Distance(Vector3 a, Vector3 b);

    inline  bool isnull()
    {
        return x == 0 && y == 0 && z == 0;
    }
    inline bool isnully()
    {
        return x == 0 && z == 0;
    }
    inline bool isvalid()
    {
        return isfloat(x) && (isfloat(y) || y == 0) && isfloat(z);
    }
    inline bool isflot()
    {
        return isfloat(x) && isfloat(y) && isfloat(z);
    }
};

inline Vector3 operator+(Vector3 lhs, const float rhs) { return Vector3(lhs.x + rhs, lhs.y + rhs, lhs.z + rhs); }
inline Vector3 operator-(Vector3 lhs, const float rhs) { return Vector3(lhs.x - rhs, lhs.y - rhs, lhs.z - rhs); }
inline Vector3 operator*(Vector3 lhs, const float rhs) { return Vector3(lhs.x * rhs, lhs.y * rhs, lhs.z * rhs); }
inline Vector3 operator/(Vector3 lhs, const float rhs) { return Vector3(lhs.x / rhs, lhs.y / rhs, lhs.z / rhs); }
inline Vector3 operator+(const float lhs, Vector3 rhs) { return Vector3(lhs + rhs.x, lhs + rhs.y, lhs + rhs.z); }
inline Vector3 operator-(const float lhs, Vector3 rhs) { return Vector3(lhs - rhs.x, lhs - rhs.y, lhs - rhs.z); }
inline Vector3 operator*(const float lhs, Vector3 rhs) { return Vector3(lhs * rhs.x, lhs * rhs.y, lhs * rhs.z); }
inline Vector3 operator/(const float lhs, Vector3 rhs) { return Vector3(lhs / rhs.x, lhs / rhs.y, lhs / rhs.z); }
inline Vector3 operator+(Vector3 lhs, const Vector3 rhs) { return Vector3(lhs.x + rhs.x, lhs.y + rhs.y, lhs.z + rhs.z); }
inline Vector3 operator-(Vector3 lhs, const Vector3 rhs) { return Vector3(lhs.x - rhs.x, lhs.y - rhs.y, lhs.z - rhs.z); }
inline Vector3 operator*(Vector3 lhs, const Vector3 rhs) { return Vector3(lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z); }
inline Vector3 operator/(Vector3 lhs, const Vector3 rhs) { return Vector3(lhs.x / rhs.x, lhs.y / rhs.y, lhs.z / rhs.z); }
inline bool operator==(const Vector3 lhs, const Vector3 rhs) { return lhs.x == rhs.x && lhs.y == rhs.y && lhs.z == rhs.z; }
inline bool operator!=(const Vector3 lhs, const Vector3 rhs) { return lhs.x != rhs.x && lhs.y != rhs.y && lhs.z != rhs.z; }
inline Vector3 operator-(Vector3 v) { return v * -1; }

inline float Vector3::Magnitude(Vector3 v) {
    return sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

inline float Vector3::Distance(Vector3 a, Vector3 b) {
    return (a - b).magnitude();
}

inline float Distance(const Vector3& a, const Vector3& b) {
    return std::sqrt(std::pow(b.x - a.x, 2) + std::pow(b.z - a.z, 2));
}

struct Vector2
{
    float x, y;

    Vector2() : x(0), y(0) {};
    Vector2(float x, float y) : x(x), y(y) {};

    bool isnull()
    {
        return x == 0 && y == 0;
    }
    bool isvalid()
    {
        return isfloat(x) && isfloat(y);
    }
    inline struct Vector2& operator+=(const float rhs);
    inline struct Vector2& operator-=(const float rhs);
    inline struct Vector2& operator*=(const float rhs);
    inline struct Vector2& operator/=(const float rhs);
    inline struct Vector2& operator+=(const Vector2 rhs);
    inline struct Vector2& operator-=(const Vector2 rhs);
};

inline Vector2& Vector2::operator+=(const float rhs)
{
    x += rhs;
    y += rhs;
    return *this;
}

inline Vector2& Vector2::operator-=(const float rhs)
{
    x -= rhs;
    y -= rhs;
    return *this;
}

inline Vector2& Vector2::operator*=(const float rhs)
{
    x *= rhs;
    y *= rhs;
    return *this;
}

inline Vector2& Vector2::operator/=(const float rhs)
{
    x /= rhs;
    y /= rhs;
    return *this;
}

inline Vector2& Vector2::operator+=(const Vector2 rhs)
{
    x += rhs.x;
    y += rhs.y;
    return *this;
}

inline Vector2& Vector2::operator-=(const Vector2 rhs)
{
    x -= rhs.x;
    y -= rhs.y;
    return *this;
}

inline Vector2 operator+(Vector2 lhs, const float rhs) { return lhs += rhs; }
inline Vector2 operator-(Vector2 lhs, const float rhs) { return lhs -= rhs; }
inline Vector2 operator*(Vector2 lhs, const float rhs) { return lhs *= rhs; }
inline Vector2 operator/(Vector2 lhs, const float rhs) { return lhs /= rhs; }
inline Vector2 operator+(const float lhs, Vector2 rhs) { return rhs += lhs; }
inline Vector2 operator-(const float lhs, Vector2 rhs) { return rhs -= lhs; }
inline Vector2 operator*(const float lhs, Vector2 rhs) { return rhs *= lhs; }
inline Vector2 operator/(const float lhs, Vector2 rhs) { return rhs /= lhs; }
inline Vector2 operator+(Vector2 lhs, const Vector2 rhs) { return lhs += rhs; }
inline Vector2 operator-(Vector2 lhs, const Vector2 rhs) { return lhs -= rhs; }

inline bool operator==(const Vector2 lhs, const Vector2 rhs)
{
    return lhs.x == rhs.x && lhs.y == rhs.y;
}

inline bool operator!=(const Vector2 lhs, const Vector2 rhs)
{
    return !(lhs == rhs);
}

inline float Dot(const Vector3& Vec1, const Vector3& Vec2)
{
    return Vec1.x * Vec2.x + Vec1.y * Vec2.y + Vec1.z * Vec2.z;
}

struct c_matrix
{
    float _11, _12, _13, _14;
    float _21, _22, _23, _24;
    float _31, _32, _33, _34;
    float _41, _42, _43, _44;

    bool WorldToScreen(Vector3 entityPos, Vector2& screenPos)
    {
        Vector3 transVec = Vector3(_14, _24, _34);
        Vector3 rightVec = Vector3(_11, _21, _31);
        Vector3 upVec = Vector3(_12, _22, _32);

        float w = Dot(transVec, entityPos) + _44;
        if (w < 0.1f) // фильтр невидимых позиций
            return false;

        float y = Dot(upVec, entityPos) + _42;
        float x = Dot(rightVec, entityPos) + _41;

        ImVec2 screenSize = ImGui::GetIO().DisplaySize;

        screenPos.x = (screenSize.x / 2.0f) * (1.0f + x / w);
        screenPos.y = (screenSize.y / 2.0f) * (1.0f - y / w); // ← важная инверсия Y

        return true;
    }
};

struct Vector4
{
    float x, y, z, w;
};

struct TMatrix
{
    Vector4 rotation;
    Vector4 position;
    Vector4 scale;
};

struct mtx_checker {
    float a0, a1, a2, a3, a4, a5;

    bool isvalid() {
        return a0 > -0.3 && a0 < -0.1 && a1 == 0 && a2 == 60 && a3 == 0 && a4 == 1 && a5 == 0;
    }
};

#define GLBlack new GLubyte[3]{0,0,0}
#define GLWhite new GLubyte[3]{255,255,255}
#define screen ImGui::GetIO().DisplaySize

static inline ImVec2 operator*(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x * rhs, lhs.y * rhs); }
static inline ImVec2 operator/(const ImVec2& lhs, const float rhs) { float inv = 1.0f / rhs; return ImVec2(lhs.x * inv, lhs.y * inv); }
static inline ImVec2 operator+(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x + rhs, lhs.y + rhs); }
static inline ImVec2 operator+(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x + rhs.x, lhs.y + rhs.y); }
static inline ImVec2 operator-(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x - rhs.x, lhs.y - rhs.y); }
static inline ImVec2 operator-(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x - rhs, lhs.y - rhs); }
static inline ImVec2 operator*(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x * rhs.x, lhs.y * rhs.y); }
static inline ImVec2 operator/(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x / rhs.x, lhs.y / rhs.y); }
static inline ImVec2& operator*=(ImVec2& lhs, const float rhs) { lhs.x *= rhs; lhs.y *= rhs; return lhs; }
static inline ImVec2& operator/=(ImVec2& lhs, const float rhs) { lhs.x /= rhs; lhs.y /= rhs; return lhs; }
static inline ImVec2& operator+=(ImVec2& lhs, const ImVec2& rhs) { lhs.x += rhs.x; lhs.y += rhs.y; return lhs; }
static inline ImVec2& operator-=(ImVec2& lhs, const ImVec2& rhs) { lhs.x -= rhs.x; lhs.y -= rhs.y; return lhs; }
static inline ImVec2& operator*=(ImVec2& lhs, const ImVec2& rhs) { lhs.x *= rhs.x; lhs.y *= rhs.y; return lhs; }
static inline ImVec2& operator/=(ImVec2& lhs, const ImVec2& rhs) { lhs.x /= rhs.x; lhs.y /= rhs.y; return lhs; }
static inline ImVec4 operator+(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x + rhs.x, lhs.y + rhs.y, lhs.z + rhs.z, lhs.w + rhs.w); }
static inline ImVec4 operator-(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x - rhs.x, lhs.y - rhs.y, lhs.z - rhs.z, lhs.w - rhs.w); }
static inline ImVec4 operator*(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z, lhs.w * rhs.w); }

struct AimTarget {
    Vector3 position = { 0,0,0 };
    float screenDistance = FLT_MAX;
    ImRect rect = { 0,0,0,0 };
    uintptr_t address = 0;
};