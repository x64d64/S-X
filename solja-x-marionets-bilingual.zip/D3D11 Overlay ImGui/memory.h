﻿#pragma once
#include <vector>
#include <mutex>
#include <Windows.h>

extern std::vector<uintptr_t> poslist;
extern uintptr_t mtxpointer_addr;
extern std::mutex data_mutex;

DWORD GetProcessIdByName(const std::wstring& processName);
HANDLE OpenProcessByName(const std::wstring& processName, DWORD* outPid = nullptr);
void MemoryScan(HANDLE hProcess);
bool memcmpv2(const char* a, const char* b, int c);
