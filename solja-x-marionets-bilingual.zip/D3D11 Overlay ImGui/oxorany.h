#pragma once
#include <string>

// Для обычных строк (const char*)
#define oxorany(str) []() -> const char* { \
    static const char* encrypted = str; \
    static std::string decrypted; \
    if (decrypted.empty()) { \
        decrypted = encrypted; \
        char* key = const_cast<char*>(decrypted.c_str()); \
        for (size_t i = 0; i < decrypted.size(); ++i) { \
            key[i] ^= 0x1F; \
        } \
    } \
    return decrypted.c_str(); \
}()

// Для юникодных строк (const wchar_t*), чтобы работало с L"текст"
#define oxoranyW(str) []() -> const wchar_t* { \
    static const wchar_t* encrypted = str; \
    static std::wstring decrypted; \
    if (decrypted.empty()) { \
        decrypted = encrypted; \
        wchar_t* key = const_cast<wchar_t*>(decrypted.c_str()); \
        for (size_t i = 0; i < decrypted.size(); ++i) { \
            key[i] ^= 0x1F; \
        } \
    } \
    return decrypted.c_str(); \
}()