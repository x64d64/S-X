﻿#pragma once
#include "pch.h"
#include "str.hpp"
#include <Windows.h>

class Esp {
public:

    bool box = true;
    bool snaplines = true;
    bool fill = true;
    bool tg_text = true;
    bool head_circle = false;
    bool customCrosshair = false;

    inline static DWORD processID = 0;
    inline static HANDLE hProcess = NULL;
    inline static ImVec2 gameWindowSize = { 1920, 1080 };

    void Initialize();
    void FindPlayers();
    void RenderESP();
};

inline Esp esp;
