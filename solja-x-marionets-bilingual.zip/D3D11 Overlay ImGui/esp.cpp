#include "ImGui/imgui.h"
#include "esp.h"
#include "Menu.h"
#include <mutex>
#include <algorithm>
#include <chrono>
#include <thread>
#include <cmath>
#include <cfloat>
#include "cheat/trigger/trigger.h"
#include "cheat/aimbot/aimbot.h"
#include "oxorany.h"

const char playerpattern[] = { 0x00, 0x00, 0x80, 0x3F, 0x00, 0x00, 0x80, 0x3F, 0x00, 0x00, 0x80, 0x3F, 0x80, 0x96, 0x18, 0x4B, 0x00, 0x00, 0x00, 0x00, 0xCD, 0xCC };

std::vector<uintptr_t> poslist;
uintptr_t mtxpointer_addr = 0;
std::mutex data_mutex;

bool memcmpv2(const char* a, const char* b, int c)
{
    for (int i = 0; i < c; i++)
        if (a[i] != b[i]) return false;
    return true;
}

float FOVDegreesToPixels(float degrees) {
    ImVec2 displaySize = ImGui::GetIO().DisplaySize;
    float diagonalRadius = sqrtf(displaySize.x * displaySize.x + displaySize.y * displaySize.y) / 2.0f;
    return (degrees / 360.0f) * diagonalRadius * 2.0f;
}

float GetAimPointHeight(int targetMode) {
    switch(targetMode) {
        case 0: return 1.8f;   // HEAD
        case 1: return 1.5f;   // NECK
        case 2: return 0.9f;   // CHEST
        default: return 1.8f;
    }
}

void MoveMouseToTarget(Vector2 target, float smooth) {
    ImVec2 screenCenter = ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f);
    
    float dx = target.x - screenCenter.x;
    float dy = target.y - screenCenter.y;

    float speed = 15.0f - (smooth * 13.5f);
    if (speed < 1.0f) speed = 1.0f;

    dx = dx / speed;
    dy = dy / speed;

    INPUT input = { 0 };
    input.type = INPUT_MOUSE;
    input.mi.dx = (LONG)dx;
    input.mi.dy = (LONG)dy;
    input.mi.dwFlags = MOUSEEVENTF_MOVE;
    SendInput(1, &input, sizeof(INPUT));
}

bool FindBestTarget(const std::vector<Vector2>& targets, float aimbotFOV) {
    Aimbot::bestTarget = Vector2{ 0.0f, 0.0f };
    Aimbot::bestDist = FLT_MAX;

    ImVec2 screenCenter = ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f);

    for (const auto& pos : targets) {
        float dx = pos.x - screenCenter.x;
        float dy = pos.y - screenCenter.y;
        float dist = sqrtf(dx * dx + dy * dy);

        if (dist < aimbotFOV && dist < Aimbot::bestDist) {
            Aimbot::bestDist = dist;
            Aimbot::bestTarget = pos;
        }
    }

    return Aimbot::bestDist != FLT_MAX;
}

DWORD GetProcessIdByName(const std::wstring& processName)
{
    PROCESSENTRY32W processInfo;
    processInfo.dwSize = sizeof(processInfo);

    HANDLE processesSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
    if (processesSnapshot == INVALID_HANDLE_VALUE) {
        return 0;
    }

    if (!Process32FirstW(processesSnapshot, &processInfo)) {
        CloseHandle(processesSnapshot);
        return 0;
    }

    do {
        if (_wcsicmp(processInfo.szExeFile, processName.c_str()) == 0) {
            CloseHandle(processesSnapshot);
            return processInfo.th32ProcessID;
        }
    } while (Process32NextW(processesSnapshot, &processInfo));

    CloseHandle(processesSnapshot);
    return 0;
}

void Esp::Initialize()
{
    processID = GetProcessIdByName(L"HD-Player.exe");
    hProcess = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, FALSE, processID);
}

void Esp::FindPlayers()
{
    while (hProcess) {
        std::vector<uintptr_t> temp_poslist;
        uintptr_t temp_mtxpointer_addr = 0;

        uintptr_t address = 0;
        MEMORY_BASIC_INFORMATION64 mm;

        while (VirtualQueryEx(hProcess, (LPCVOID)address, (PMEMORY_BASIC_INFORMATION)&mm, sizeof(mm))) {
            if (mm.Protect == PAGE_READWRITE && mm.State == MEM_COMMIT && mm.Type == MEM_PRIVATE &&
                (uintptr_t)mm.BaseAddress < 0x2FFFFFFFF && mm.RegionSize == 2097152) {

                char* buffer = new (std::nothrow) char[mm.RegionSize];
                if (!buffer) {
                    address = (uintptr_t)mm.BaseAddress + mm.RegionSize;
                    continue;
                }

                SIZE_T bytesRead = 0;
                if (ReadProcessMemory(hProcess, (void*)mm.BaseAddress, buffer, mm.RegionSize, &bytesRead)) {
                    for (uintptr_t curadd_offset = 0; curadd_offset < bytesRead; curadd_offset += 4) {
                        uintptr_t curadd_in_buffer = (uintptr_t)buffer + curadd_offset;
                        uintptr_t curadd_in_process = (uintptr_t)mm.BaseAddress + curadd_offset;

                        if (curadd_offset + sizeof(playerpattern) <= bytesRead) {
                            if (memcmpv2((char*)curadd_in_buffer, (char*)playerpattern, sizeof(playerpattern))) {
                                uintptr_t poss_addr = curadd_in_process - sizeof(Vector4) * 2;
                                TMatrix checkMatrix;
                                if (ReadProcessMemory(hProcess, (LPCVOID)poss_addr, &checkMatrix, sizeof(TMatrix), NULL)) {
                                    if (checkMatrix.scale.x == 1.f && checkMatrix.rotation.x == 0.f) {
                                        temp_poslist.push_back(poss_addr);
                                    }
                                }
                            }
                        }

                        if (curadd_offset + sizeof(mtx_checker) <= bytesRead) {
                            mtx_checker* checker = (mtx_checker*)curadd_in_buffer;
                            if (checker->isvalid()) {
                                temp_mtxpointer_addr = (curadd_in_process - 0x178 + 0x100);
                                c_matrix test_mtx;
                                if (!ReadProcessMemory(hProcess, (LPCVOID)temp_mtxpointer_addr, &test_mtx, sizeof(c_matrix), NULL)) {
                                    temp_mtxpointer_addr = 0;
                                }
                            }
                        }
                    }
                }
                delete[] buffer;
            }
            address = (uintptr_t)mm.BaseAddress + mm.RegionSize;
            if (mm.RegionSize == 0) break;
        }

        {
            std::lock_guard<std::mutex> lock(data_mutex);
            if (!temp_poslist.empty()) poslist = std::move(temp_poslist);
            if (temp_mtxpointer_addr != 0) mtxpointer_addr = temp_mtxpointer_addr;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
}

void Esp::RenderESP()
{
    if (!hProcess) return;

    // Обновляем состояние аимера (стрельба, bind)
    Aimbot::Update();
    
    // RGB и бинд работают всегда
    Menu::TickRgbAlways();
    
    // Draw aimbot status indicator everywhere
    Menu::DrawAimbotStatus();

    auto draw = ImGui::GetBackgroundDrawList();

    std::vector<uintptr_t> current_poslist;
    uintptr_t current_mtxpointer_addr = 0;
    {
        std::lock_guard<std::mutex> lock(data_mutex);
        current_poslist = poslist;
        current_mtxpointer_addr = mtxpointer_addr;
    }
    if (current_mtxpointer_addr == 0) return;
    c_matrix view_matrix;
    if (!ReadProcessMemory(hProcess, (LPCVOID)current_mtxpointer_addr, &view_matrix, sizeof(view_matrix), NULL)) {
        return;
    }

    std::vector<Vector2> potentialTargets;
    ImVec2 screenCenter = ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f);
    bool is360FOV = (Aimbot::fov >= 359.0f);

    Trigger::trigger.ClearBoxCoordinates();

    for (const auto& addr : current_poslist) {
        TMatrix player_matrix{};
        if (!ReadProcessMemory(hProcess, (LPCVOID)addr, &player_matrix, sizeof(player_matrix), NULL)) {
            continue;
        }
        if (player_matrix.scale.x == 1.f && player_matrix.rotation.x == 0.f) {
            Vector2 feet_screen, head_screen;
            bool feetVisible = view_matrix.WorldToScreen({ player_matrix.position.x, player_matrix.position.y, player_matrix.position.z }, feet_screen);
            bool headVisible = view_matrix.WorldToScreen({ player_matrix.position.x, player_matrix.position.y + 1.8f, player_matrix.position.z }, head_screen);

            if (feetVisible && headVisible) {
                float height = fabsf(head_screen.y - feet_screen.y);
                float width = height * 0.4f;
                width *= 1.3f;

                float left = feet_screen.x - width / 2;
                float right = feet_screen.x + width / 2;
                float top = head_screen.y;
                float bottom = feet_screen.y;
                float centerX = (left + right) * 0.5f;
                float centerY = (top + bottom) * 0.5f;

                Vector3 cameraPos = Vector3(view_matrix._41, view_matrix._42, view_matrix._43);
                Vector3 playerPos = Vector3(player_matrix.position.x, player_matrix.position.y, player_matrix.position.z);
                Vector3 diff = playerPos - cameraPos;
                float distance = sqrtf(diff.x * diff.x + diff.y * diff.y + diff.z * diff.z) / 100.0f;

                // Get aim point based on target mode
                Vector2 aimPos = { 0.0f, 0.0f };
                float aimHeight = GetAimPointHeight(Aimbot::targetMode);
                Vector2 targetScreen;
                
                if (view_matrix.WorldToScreen({ player_matrix.position.x, player_matrix.position.y + aimHeight, player_matrix.position.z }, targetScreen)) {
                    aimPos = targetScreen;
                } else {
                    aimPos.x = centerX;
                    aimPos.y = centerY;
                }

                if (Aimbot::enabled) {
                    if (is360FOV) {
                        potentialTargets.push_back(aimPos);
                    } else {
                        float fovPixels = FOVDegreesToPixels(Aimbot::fov);
                        float dx = aimPos.x - screenCenter.x;
                        float dy = aimPos.y - screenCenter.y;
                        float dist = sqrtf(dx * dx + dy * dy);
                        if (dist < fovPixels) {
                            potentialTargets.push_back(aimPos);
                        }
                    }
                }

                ImU32 colBox = ImGui::ColorConvertFloat4ToU32(Menu::colEspBox);
                ImU32 colSnaplines = ImGui::ColorConvertFloat4ToU32(Menu::colEspSnaplines);
                ImU32 colFill = ImGui::ColorConvertFloat4ToU32(Menu::colEspFill);
                ImU32 colHeadCircle = ImGui::ColorConvertFloat4ToU32(Menu::colEspHeadCircle);
                ImU32 colCrosshair = ImGui::ColorConvertFloat4ToU32(Menu::colCrosshair);

                // ===== BOX RENDERING =====
                if (Menu::espBox)
                {
                    if (Menu::boxMode == 0)
                    {
                        float thickness = Menu::espLineThickness;
                        float outerOffset = 1.5f;
                        float innerOffset = 1.5f;

                        draw->AddRect(
                            ImVec2(left - outerOffset, top - outerOffset),
                            ImVec2(right + outerOffset, bottom + outerOffset),
                            IM_COL32(0, 0, 0, 255),
                            0.0f, 0, thickness
                        );

                        draw->AddRect(
                            ImVec2(left, top),
                            ImVec2(right, bottom),
                            colBox,
                            0.0f, 0, thickness
                        );

                        draw->AddRect(
                            ImVec2(left + innerOffset, top + innerOffset),
                            ImVec2(right - innerOffset, bottom - innerOffset),
                            IM_COL32(0, 0, 0, 255),
                            0.0f, 0, thickness
                        );
                    }
                    else if (Menu::boxMode == 1)
                    {
                        float thickness = Menu::espLineThickness;
                        float cornerSize = (right - left) * 0.2f;
                        float corner_y = (bottom - top) * 0.2f;

                        draw->AddLine(ImVec2(left, top), ImVec2(left + cornerSize, top), colBox, thickness);
                        draw->AddLine(ImVec2(left, top), ImVec2(left, top + corner_y), colBox, thickness);

                        draw->AddLine(ImVec2(right, top), ImVec2(right - cornerSize, top), colBox, thickness);
                        draw->AddLine(ImVec2(right, top), ImVec2(right, top + corner_y), colBox, thickness);

                        draw->AddLine(ImVec2(left, bottom), ImVec2(left + cornerSize, bottom), colBox, thickness);
                        draw->AddLine(ImVec2(left, bottom), ImVec2(left, bottom - corner_y), colBox, thickness);

                        draw->AddLine(ImVec2(right, bottom), ImVec2(right - cornerSize, bottom), colBox, thickness);
                        draw->AddLine(ImVec2(right, bottom), ImVec2(right, bottom - corner_y), colBox, thickness);
                    }
                    else if (Menu::boxMode == 2)
                    {
                        float thickness = Menu::espLineThickness;
                        float boxWidth = right - left;
                        float boxHeight = bottom - top;
                        
                        float depth = (boxWidth + boxHeight) * 0.08f;
                        if (distance > 100.0f) {
                            depth *= 0.3f;
                        } else if (distance > 50.0f) {
                            depth *= 0.6f;
                        }
                        depth = ImMax(depth, 1.5f);

                        draw->AddRect(ImVec2(left, top), ImVec2(right, bottom), colBox, 0.0f, 0, thickness);

                        draw->AddRect(
                            ImVec2(left + depth, top + depth),
                            ImVec2(right + depth, bottom + depth),
                            colBox, 0.0f, 0, thickness
                        );

                        draw->AddLine(ImVec2(left, top), ImVec2(left + depth, top + depth), colBox, thickness);
                        draw->AddLine(ImVec2(right, top), ImVec2(right + depth, top + depth), colBox, thickness);
                        draw->AddLine(ImVec2(left, bottom), ImVec2(left + depth, bottom + depth), colBox, thickness);
                        draw->AddLine(ImVec2(right, bottom), ImVec2(right + depth, bottom + depth), colBox, thickness);
                    }
                    
                    Trigger::trigger.HandleTrigger(left, top, right, bottom);
                }

                // ===== FILL RENDERING =====
                if (Menu::espFill)
                {
                    ImVec4 fillCol = Menu::colEspFill;
                    fillCol.w = Menu::fillAlpha;
                    ImU32 fillColU32 = ImGui::ColorConvertFloat4ToU32(fillCol);
                    draw->AddRectFilled(
                        ImVec2(left, top),
                        ImVec2(right, bottom),
                        fillColU32
                    );
                }

                // ===== SNAPLINES RENDERING =====
                if (Menu::espSnaplines)
                {
                    if (Menu::snaplineMode == 0)
                    {
                        ImVec2 screenBottom = ImVec2(screenCenter.x, ImGui::GetIO().DisplaySize.y);
                        draw->AddLine(
                            screenBottom,
                            ImVec2(centerX, centerY),
                            colSnaplines,
                            Menu::espLineThickness
                        );
                    }
                    else
                    {
                        ImVec2 screenTop = ImVec2(screenCenter.x, 0);
                        draw->AddLine(
                            screenTop,
                            ImVec2(centerX, centerY),
                            colSnaplines,
                            Menu::espLineThickness
                        );
                    }
                }

                // ===== HEAD CIRCLE RENDERING =====
                if (Menu::espHeadCircle)
                {
                    float headRadius = fabsf(right - left) * 0.15f;
                    float headOffsetY = height * 0.1f;
                    draw->AddCircle(ImVec2(head_screen.x, head_screen.y + headOffsetY), headRadius, colHeadCircle, 32, 1.5f);
                }            }
            else if (is360FOV && Aimbot::enabled) {
                Vector2 body_center;
                if (view_matrix.WorldToScreen({ player_matrix.position.x, player_matrix.position.y + 1.8f * 0.5f, player_matrix.position.z }, body_center)) {
                    potentialTargets.push_back(body_center);
                }
            }
        }
    }

    if (Aimbot::enabled) {
        float fovPixels_final = FOVDegreesToPixels(Aimbot::fov);
        FindBestTarget(potentialTargets, fovPixels_final);
    }

    // Aimbot activation
    bool aimbotPressed = true;
    if (Aimbot::useBind) {
        aimbotPressed = Aimbot::bindActive;
    } else {
        aimbotPressed = true;
    }

    // Draw FOV circle
    if (Aimbot::enabled && Aimbot::showFov) {
        ImVec2 center(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f);
        ImU32 colAimbotFov = ImGui::ColorConvertFloat4ToU32(Menu::colAimbotFov);
        if (Aimbot::fov >= 359.0f) {
            float diagonalRadius = sqrtf(ImGui::GetIO().DisplaySize.x * ImGui::GetIO().DisplaySize.x + ImGui::GetIO().DisplaySize.y * ImGui::GetIO().DisplaySize.y) / 2.0f;
            draw->AddCircle(center, diagonalRadius * 2.0f, colAimbotFov, 64, Menu::aimbotFovThickness);
        } else {
            float fovPixels = FOVDegreesToPixels(Aimbot::fov);
            draw->AddCircle(center, fovPixels, colAimbotFov, 64, Menu::aimbotFovThickness);
        }
    }

    // Показать куда целится аим
    if (Aimbot::enabled && Aimbot::showWhereToAim && Aimbot::bestDist != FLT_MAX) {
        ImU32 aimCol = ImGui::ColorConvertFloat4ToU32(Menu::colAimbotFov);
        float pointRadius = 4.0f;
        draw->AddCircleFilled(ImVec2(Aimbot::bestTarget.x, Aimbot::bestTarget.y), pointRadius, aimCol);
    }

    // ===== CUSTOM CROSSHAIR =====
    if (Menu::customCrosshair)
    {
        ImU32 crossCol = ImGui::ColorConvertFloat4ToU32(Menu::colCrosshair);
        float crossSize = Menu::crosshairSize;
        float gap = Menu::crosshairGap;

        if (Menu::crosshairMode == 0)
        {
            draw->AddCircle(screenCenter, crossSize, crossCol, 16, Menu::crosshairThickness);
        }
        else if (Menu::crosshairMode == 1)
        {
            draw->AddLine(ImVec2(screenCenter.x - crossSize, screenCenter.y), ImVec2(screenCenter.x - gap, screenCenter.y), crossCol, Menu::crosshairThickness);
            draw->AddLine(ImVec2(screenCenter.x + gap, screenCenter.y), ImVec2(screenCenter.x + crossSize, screenCenter.y), crossCol, Menu::crosshairThickness);
            draw->AddLine(ImVec2(screenCenter.x, screenCenter.y - crossSize), ImVec2(screenCenter.x, screenCenter.y - gap), crossCol, Menu::crosshairThickness);
            draw->AddLine(ImVec2(screenCenter.x, screenCenter.y + gap), ImVec2(screenCenter.x, screenCenter.y + crossSize), crossCol, Menu::crosshairThickness);
        }
        else if (Menu::crosshairMode == 2)
        {
            draw->AddLine(ImVec2(screenCenter.x - crossSize, screenCenter.y), ImVec2(screenCenter.x + crossSize, screenCenter.y), crossCol, Menu::crosshairThickness);
            draw->AddLine(ImVec2(screenCenter.x, screenCenter.y), ImVec2(screenCenter.x, screenCenter.y + crossSize + gap), crossCol, Menu::crosshairThickness);
        }
    }

    // ===== AIMBOT EXECUTION =====
    if (Aimbot::enabled && Aimbot::bestDist != FLT_MAX && aimbotPressed) {
        bool shouldAim = !Aimbot::workOnlyShooting || Aimbot::isShooting;
        
        if (shouldAim) {
            MoveMouseToTarget(Aimbot::bestTarget, Aimbot::smooth);
        }
    }

    Trigger::trigger.DrawTriggerZone();
}