﻿#pragma once
#include "ImGui/imgui.h"

namespace GUI
{
    bool FilledCheckbox(const char* label, bool* v, ImU32 activeColor, float size = 12.0f);
}
