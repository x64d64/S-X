﻿#pragma once
#include "ImGui/imgui.h"

namespace GUI
{
    bool CustomSliderFloat(const char* label, float& value, float min, float max, const ImVec2& size, ImU32 accentColor);
}
