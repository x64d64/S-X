﻿#pragma once
#include "ImGui/imgui.h"
#include <vector>

namespace GUI
{
    bool CustomComboBox(const char* label, int& currentItem, const std::vector<const char*>& items, ImU32 accentColor, const ImVec2& size)
    {
        ImGui::PushID(label);
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImDrawList* overlay = ImGui::GetForegroundDrawList();
        ImVec2 pos = ImGui::GetCursorScreenPos();
        static bool open = false;
        bool changed = false;

        draw_list->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(7, 7, 7, 255));
        draw_list->AddRect(pos, ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(17, 17, 17, 255));

        if (!items.empty() && currentItem >= 0 && currentItem < items.size())
        {
            ImVec2 textPos(pos.x + 4, pos.y + (size.y - ImGui::CalcTextSize(items[currentItem]).y) * 0.5f);
            draw_list->AddText(textPos, IM_COL32(200, 200, 200, 255), items[currentItem]);
        }

        ImVec2 arrowCenter(pos.x + size.x - 10, pos.y + size.y * 0.5f);
        draw_list->AddLine(ImVec2(arrowCenter.x - 4, arrowCenter.y - 2), ImVec2(arrowCenter.x, arrowCenter.y + 2), IM_COL32(200, 200, 200, 255), 1.0f);
        draw_list->AddLine(ImVec2(arrowCenter.x, arrowCenter.y + 2), ImVec2(arrowCenter.x + 4, arrowCenter.y - 2), IM_COL32(200, 200, 200, 255), 1.0f);

        ImGui::SetCursorScreenPos(pos);
        ImGui::InvisibleButton("##combo_btn", size);
        if (ImGui::IsItemClicked())
            open = !open;

        if (open)
        {
            ImVec2 popupPos = ImVec2(pos.x, pos.y + size.y);
            ImVec2 popupSize(size.x, size.y * items.size());

            overlay->AddRectFilled(popupPos, ImVec2(popupPos.x + popupSize.x, popupPos.y + popupSize.y), IM_COL32(7, 7, 7, 255));
            overlay->AddRect(popupPos, ImVec2(popupPos.x + popupSize.x, popupPos.y + popupSize.y), IM_COL32(17, 17, 17, 255));

            for (int i = 0; i < items.size(); i++)
            {
                ImVec2 itemPos = ImVec2(popupPos.x + 4, popupPos.y + i * size.y + (size.y - ImGui::CalcTextSize(items[i]).y) * 0.5f);
                ImU32 col = (i == currentItem) ? accentColor : IM_COL32(230, 230, 230, 255);
                overlay->AddText(itemPos, col, items[i]);

                ImVec2 mousePos = ImGui::GetIO().MousePos;
                if (mousePos.x >= popupPos.x && mousePos.x <= popupPos.x + popupSize.x &&
                    mousePos.y >= popupPos.y + i * size.y && mousePos.y <= popupPos.y + (i + 1) * size.y)
                {
                    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left))
                    {
                        currentItem = i;
                        changed = true;
                        open = false;
                    }
                }
            }
        }

        ImGui::PopID();
        return changed;
    }
}
