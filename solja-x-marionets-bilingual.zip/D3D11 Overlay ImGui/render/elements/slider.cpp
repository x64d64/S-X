﻿#include "Slider.h"

namespace GUI
{
    bool CustomSliderFloat(const char* label, float& value, float min, float max, const ImVec2& size, ImU32 accentColor)
    {
        ImGui::PushID(label);
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImVec2 pos = ImGui::GetCursorScreenPos();
        bool changed = false;

        ImGui::InvisibleButton("##slider", size);
        if (ImGui::IsItemActive() && ImGui::GetIO().MouseDown[0])
        {
            float mouseX = ImGui::GetIO().MousePos.x - pos.x;
            if (mouseX < 0) mouseX = 0;
            if (mouseX > size.x) mouseX = size.x;
            float t = mouseX / size.x;
            value = min + t * (max - min);
            changed = true;
        }

        draw_list->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(7, 7, 7, 255));
        draw_list->AddRect(pos, ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(17, 17, 17, 255));

        float tValue = (value - min) / (max - min);
        draw_list->AddRectFilled(pos, ImVec2(pos.x + tValue * size.x, pos.y + size.y), accentColor);

        ImVec2 textSize = ImGui::CalcTextSize(label);
        draw_list->AddText(ImVec2(pos.x, pos.y - textSize.y - 2), IM_COL32(200, 200, 200, 255), label);

        ImGui::PopID();
        return changed;
    }
}
