﻿#pragma once
#include "ImGui/imgui.h"

namespace GUI
{
    void FilledColorPicker(const char* label, ImU32& accentColor, const ImVec2& size = ImVec2(60, 16));
}
