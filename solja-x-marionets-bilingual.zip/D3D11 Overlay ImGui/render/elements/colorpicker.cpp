﻿#include "ColorPicker.h"

namespace GUI
{
    void FilledColorPicker(const char* label, ImU32& accentColor, const ImVec2& size)
    {
        ImGui::PushID(label);

        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImVec2 pos = ImGui::GetCursorScreenPos();
        ImVec2 text_size = ImGui::CalcTextSize(label);
        ImVec2 total_size(size.x + 4 + text_size.x, size.y > text_size.y ? size.y : text_size.y);

        ImGui::InvisibleButton("##color_picker", total_size);
        if (ImGui::IsItemClicked())
            ImGui::OpenPopup(label);

        draw_list->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), accentColor);

        draw_list->AddRect(
            pos,
            ImVec2(pos.x + size.x, pos.y + size.y),
            IM_COL32(0, 0, 0, 255),
            0.0f, 0, 1.0f
        );

        float text_offset_y = -3.0f;
        draw_list->AddText(
            ImVec2(pos.x + size.x + 4.0f, pos.y + text_offset_y),
            IM_COL32(200, 200, 200, 255),
            label
        );

        if (ImGui::BeginPopup(label))
        {
            float r = ((accentColor >> IM_COL32_R_SHIFT) & 0xFF) / 255.0f;
            float g = ((accentColor >> IM_COL32_G_SHIFT) & 0xFF) / 255.0f;
            float b = ((accentColor >> IM_COL32_B_SHIFT) & 0xFF) / 255.0f;
            float a = ((accentColor >> IM_COL32_A_SHIFT) & 0xFF) / 255.0f;
            ImVec4 colorVec(r, g, b, a);

            if (ImGui::ColorPicker4("##picker", (float*)&colorVec,
                ImGuiColorEditFlags_NoSmallPreview | ImGuiColorEditFlags_AlphaBar))
            {
                accentColor = IM_COL32(
                    (int)(colorVec.x * 255),
                    (int)(colorVec.y * 255),
                    (int)(colorVec.z * 255),
                    (int)(colorVec.w * 255)
                );
            }

            ImGui::EndPopup();
        }

        ImGui::PopID();
    }
}
