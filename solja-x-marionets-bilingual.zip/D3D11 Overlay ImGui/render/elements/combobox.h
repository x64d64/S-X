﻿#pragma once
#include "ImGui/imgui.h"
#include <vector>
#include <string>

namespace GUI
{
    bool CustomComboBox(const char* label, int& currentItem, const std::vector<const char*>& items, ImU32 accentColor, const ImVec2& size = ImVec2(100, 20));
}
