﻿#include "Checkbox.h"

namespace GUI
{
    bool FilledCheckbox(const char* label, bool* v, ImU32 activeColor, float size)
    {
        ImGui::PushID(label);

        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImVec2 pos = ImGui::GetCursorScreenPos();
        ImVec2 text_size = ImGui::CalcTextSize(label);
        ImVec2 total_size(size + 4 + text_size.x, size > text_size.y ? size : text_size.y);

        ImGui::InvisibleButton("##filled_checkbox", total_size);
        if (ImGui::IsItemClicked())
            *v = !*v;

        ImU32 fillColor = *v ? activeColor : IM_COL32(19, 19, 19, 255);
        ImU32 borderColor = IM_COL32(0, 0, 0, 255);

        draw_list->AddRectFilled(pos, ImVec2(pos.x + size, pos.y + size), fillColor);
        draw_list->AddRect(pos, ImVec2(pos.x + size, pos.y + size), borderColor);

        float text_offset_y = -3.0f;
        ImU32 textColor = *v ? IM_COL32(200, 200, 200, 255) : IM_COL32(100, 100, 100, 255);
        draw_list->AddText(ImVec2(pos.x + size + 6.0f, pos.y + text_offset_y), textColor, label);

        ImGui::PopID();
        return *v;
    }
}
