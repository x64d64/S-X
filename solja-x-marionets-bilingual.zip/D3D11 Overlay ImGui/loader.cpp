#include "Loader.h"
#include "Menu.h"
#include "UI.h"
#include "config_system.h"
#include <Windows.h>
#include <vector>
#include <string>
#include <algorithm>
#include <cctype>

UI::WindowItem Drawing::lpSelectedWindow = { nullptr, "", "" };
bool Drawing::menuKey = true;

static std::string ToLowerStr(const char* s)
{
    std::string res = s ? s : "";
    std::transform(res.begin(), res.end(), res.begin(),
        [](unsigned char c) { return std::tolower(c); });
    return res;
}

static std::string ExtractFileName(const char* fullPath)
{
    if (!fullPath) return "";
    const char* p1 = strrchr(fullPath, '\\');
    const char* p2 = strrchr(fullPath, '/');
    const char* p = (p1 > p2) ? p1 : p2;
    return std::string(p ? p + 1 : fullPath);
}

static std::string RemoveExeExtension(const std::string& nameLower)
{
    if (nameLower.size() > 4 && nameLower.substr(nameLower.size() - 4) == ".exe")
        return nameLower.substr(0, nameLower.size() - 4);
    return nameLower;
}

bool UI::GetWindowByProcessName(const char* processName, UI::WindowItem* outWindow)
{
    if (!processName || !outWindow)
        return false;

    std::vector<UI::WindowItem> WindowList;
    UI::GetAllWindow(&WindowList);

    std::string userNameLower = ToLowerStr(processName);
    std::string userNameNoExe = RemoveExeExtension(userNameLower);

    for (const auto& item : WindowList)
    {
        std::string processNameLower = ToLowerStr(item.CurrentProcessName);
        std::string processNameNoExe = RemoveExeExtension(processNameLower);

        if (processNameNoExe == userNameNoExe)
        {
            *outWindow = item;
            return true;
        }
    }
    return false;
}

void Drawing::Draw()
{
    static bool initialized = false;

    if (!initialized)
    {
        UI::WindowItem targetWindow;
        if (UI::GetWindowByProcessName("bluestacks", &targetWindow))
        {
            UI::SetTargetWindow(targetWindow.CurrentWindow);
            lpSelectedWindow = targetWindow;
            initialized = true;
            static std::string startupConfigMessage;
            ConfigSystem::Load("default", startupConfigMessage);
        }
        else
        {
            exit(0);
        }
    }

    if (GetAsyncKeyState(VK_DELETE) & 1)
        menuKey = !menuKey;
    Menu::DrawKeybinds();

    // Unload — PostQuitMessage корректно завершает render loop в UI.cpp
    if (Menu::unloadRequested)
        PostQuitMessage(0);

    if (menuKey)
        Menu::Draw();
}
