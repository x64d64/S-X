#pragma once
#include <string>
#include <vector>

namespace ConfigSystem
{
    bool Save(const std::string& name, std::string& message);
    bool Load(const std::string& name, std::string& message);
    bool List(std::vector<std::string>& names, std::string& message);
}
