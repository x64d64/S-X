#include "config_system.h"
#include "menu.h"
#include "cheat/aimbot/aimbot.h"
#include "cheat/trigger/trigger.h"
#include <Windows.h>
#include <algorithm>
#include <cctype>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <locale>
#include <sstream>
#include <unordered_map>
#include <vector>

namespace
{
    using Fields = std::vector<std::pair<std::string, std::string>>;
    using Values = std::unordered_map<std::string, std::string>;

    bool GetConfigPath(const std::string& name, std::filesystem::path& path, std::string& message, bool createDirectory)
    {
        if (name.empty() || name.size() > 32)
        {
            message = "Config name must contain 1 to 32 characters.";
            return false;
        }

        std::string safeName;
        safeName.reserve(name.size());
        for (unsigned char c : name)
        {
            if (std::isalnum(c) || c == '_' || c == '-' || c == ' ')
                safeName.push_back(c == ' ' ? '_' : static_cast<char>(c));
            else
            {
                message = "Use only letters, digits, spaces, _ and -.";
                return false;
            }
        }

        wchar_t appData[MAX_PATH]{};
        const DWORD length = GetEnvironmentVariableW(L"APPDATA", appData, ARRAYSIZE(appData));
        if (length == 0 || length >= ARRAYSIZE(appData))
        {
            message = "APPDATA path is unavailable.";
            return false;
        }

        const auto directory = std::filesystem::path(appData) / L"Solja X Marionets" / L"configs";
        try
        {
            if (createDirectory)
                std::filesystem::create_directories(directory);
            path = directory / (safeName + ".ini");
        }
        catch (const std::filesystem::filesystem_error&)
        {
            message = "Could not access the config folder.";
            return false;
        }
        return true;
    }

    std::string FloatText(float value)
    {
        std::ostringstream stream;
        stream.imbue(std::locale::classic());
        stream << std::setprecision(9) << value;
        return stream.str();
    }

    void AddBool(Fields& fields, const char* key, bool value) { fields.emplace_back(key, value ? "1" : "0"); }
    void AddInt(Fields& fields, const char* key, int value) { fields.emplace_back(key, std::to_string(value)); }
    void AddFloat(Fields& fields, const std::string& key, float value) { fields.emplace_back(key, FloatText(value)); }

    void AddColor(Fields& fields, const char* key, const ImVec4& color)
    {
        const std::string prefix(key);
        AddFloat(fields, prefix + ".r", color.x);
        AddFloat(fields, prefix + ".g", color.y);
        AddFloat(fields, prefix + ".b", color.z);
        AddFloat(fields, prefix + ".a", color.w);
    }

    void AddRgb(Fields& fields, const char* key, const Menu::RgbState& rgb)
    {
        const std::string prefix(key);
        AddBool(fields, (prefix + ".enabled").c_str(), rgb.enabled);
        AddFloat(fields, prefix + ".speed", rgb.speed);
        AddFloat(fields, prefix + ".hue", rgb.hue);
    }

    bool ReadBool(const Values& values, const std::string& key, bool& value)
    {
        const auto it = values.find(key);
        if (it == values.end()) return false;
        if (it->second == "1" || it->second == "true") value = true;
        else if (it->second == "0" || it->second == "false") value = false;
        else return false;
        return true;
    }

    bool ReadInt(const Values& values, const std::string& key, int& value, int minimum, int maximum)
    {
        const auto it = values.find(key);
        if (it == values.end()) return false;
        try
        {
            size_t used = 0;
            const long parsed = std::stol(it->second, &used);
            if (used != it->second.size() || parsed < minimum || parsed > maximum) return false;
            value = static_cast<int>(parsed);
            return true;
        }
        catch (...) { return false; }
    }

    bool ReadFloat(const Values& values, const std::string& key, float& value, float minimum, float maximum)
    {
        const auto it = values.find(key);
        if (it == values.end()) return false;
        try
        {
            size_t used = 0;
            const float parsed = std::stof(it->second, &used);
            if (used != it->second.size() || !std::isfinite(parsed) || parsed < minimum || parsed > maximum) return false;
            value = parsed;
            return true;
        }
        catch (...) { return false; }
    }

    void ReadColor(const Values& values, const char* key, ImVec4& color)
    {
        const std::string prefix(key);
        ReadFloat(values, prefix + ".r", color.x, 0.f, 1.f);
        ReadFloat(values, prefix + ".g", color.y, 0.f, 1.f);
        ReadFloat(values, prefix + ".b", color.z, 0.f, 1.f);
        ReadFloat(values, prefix + ".a", color.w, 0.f, 1.f);
    }

    void ReadRgb(const Values& values, const char* key, Menu::RgbState& rgb)
    {
        const std::string prefix(key);
        ReadBool(values, prefix + ".enabled", rgb.enabled);
        ReadFloat(values, prefix + ".speed", rgb.speed, 0.1f, 10.f);
        ReadFloat(values, prefix + ".hue", rgb.hue, 0.f, 1.f);
    }

    void CollectFields(Fields& fields)
    {
        AddBool(fields, "menu.overlayMode", Menu::overlayMode);
        AddInt(fields, "menu.language", Menu::language);
        AddBool(fields, "visuals.sharedColor", Menu::useSharedVisualColor);
        AddColor(fields, "visuals.shared", Menu::colSharedVisual);
        AddRgb(fields, "visuals.shared.rgb", Menu::rgbSharedVisual);
        AddFloat(fields, "visuals.lineThickness", Menu::espLineThickness);
        AddFloat(fields, "visuals.snaplineOpacity", Menu::snaplineOpacity);
        AddFloat(fields, "visuals.crosshairSize", Menu::crosshairSize);
        AddFloat(fields, "visuals.crosshairGap", Menu::crosshairGap);
        AddFloat(fields, "visuals.crosshairThickness", Menu::crosshairThickness);
        AddFloat(fields, "aimbot.fov.thickness", Menu::aimbotFovThickness);

        AddBool(fields, "esp.box", Menu::espBox); AddInt(fields, "esp.box.mode", Menu::boxMode); AddColor(fields, "esp.box.color", Menu::colEspBox); AddRgb(fields, "esp.box.rgb", Menu::rgbEspBox);
        AddBool(fields, "esp.snaplines", Menu::espSnaplines); AddInt(fields, "esp.snaplines.mode", Menu::snaplineMode); AddColor(fields, "esp.snaplines.color", Menu::colEspSnaplines); AddRgb(fields, "esp.snaplines.rgb", Menu::rgbEspSnaplines);
        AddBool(fields, "esp.fill", Menu::espFill); AddFloat(fields, "esp.fill.alpha", Menu::fillAlpha); AddColor(fields, "esp.fill.color", Menu::colEspFill); AddRgb(fields, "esp.fill.rgb", Menu::rgbEspFill);
        AddBool(fields, "esp.headCircle", Menu::espHeadCircle); AddColor(fields, "esp.headCircle.color", Menu::colEspHeadCircle); AddRgb(fields, "esp.headCircle.rgb", Menu::rgbEspHeadCircle);
        AddBool(fields, "esp.crosshair", Menu::customCrosshair); AddInt(fields, "esp.crosshair.mode", Menu::crosshairMode); AddColor(fields, "esp.crosshair.color", Menu::colCrosshair); AddRgb(fields, "esp.crosshair.rgb", Menu::rgbCrosshair);

        AddBool(fields, "aimbot.enabled", Aimbot::enabled); AddBool(fields, "aimbot.useBind", Aimbot::useBind); AddInt(fields, "aimbot.bindKey", Menu::aimbotBindKey); AddInt(fields, "aimbot.bindMode", Menu::aimbotBindMode);
        AddFloat(fields, "aimbot.fov", Menu::aimbotFov); AddFloat(fields, "aimbot.smooth", Menu::aimbotSmooth); AddInt(fields, "aimbot.target", Menu::aimbotTarget);
        AddBool(fields, "aimbot.workOnlyShooting", Menu::aimbotWorkOnlyShooting); AddBool(fields, "aimbot.showWhereToAim", Menu::aimbotShowWhereToAim); AddBool(fields, "aimbot.showFov", Aimbot::showFov);
        AddColor(fields, "aimbot.fov.color", Menu::colAimbotFov); AddRgb(fields, "aimbot.fov.rgb", Menu::rgbAimbotFov);

        AddBool(fields, "trigger.enabled", Trigger::trigger.triggerBot); AddBool(fields, "trigger.useBind", Trigger::trigger.useBind);
        AddInt(fields, "trigger.bindKey", Trigger::trigger.bindKey); AddInt(fields, "trigger.bindMode", static_cast<int>(Trigger::trigger.bindMode)); AddInt(fields, "trigger.delayMs", Trigger::trigger.delayMs);
    }

    void ApplyValues(const Values& values)
    {
        ReadBool(values, "menu.overlayMode", Menu::overlayMode);
        ReadInt(values, "menu.language", Menu::language, 0, 1);
        ReadBool(values, "visuals.sharedColor", Menu::useSharedVisualColor);
        ReadColor(values, "visuals.shared", Menu::colSharedVisual);
        ReadRgb(values, "visuals.shared.rgb", Menu::rgbSharedVisual);
        ReadFloat(values, "visuals.lineThickness", Menu::espLineThickness, 0.5f, 2.0f);
        ReadFloat(values, "visuals.snaplineOpacity", Menu::snaplineOpacity, 0.1f, 1.0f);
        ReadFloat(values, "visuals.crosshairSize", Menu::crosshairSize, 2.0f, 16.0f);
        ReadFloat(values, "visuals.crosshairGap", Menu::crosshairGap, 0.0f, 10.0f);
        ReadFloat(values, "visuals.crosshairThickness", Menu::crosshairThickness, 0.5f, 2.5f);
        ReadFloat(values, "aimbot.fov.thickness", Menu::aimbotFovThickness, 0.5f, 2.5f);

        ReadBool(values, "esp.box", Menu::espBox); ReadInt(values, "esp.box.mode", Menu::boxMode, 0, 2); ReadColor(values, "esp.box.color", Menu::colEspBox); ReadRgb(values, "esp.box.rgb", Menu::rgbEspBox);
        ReadBool(values, "esp.snaplines", Menu::espSnaplines); ReadInt(values, "esp.snaplines.mode", Menu::snaplineMode, 0, 1); ReadColor(values, "esp.snaplines.color", Menu::colEspSnaplines); ReadRgb(values, "esp.snaplines.rgb", Menu::rgbEspSnaplines);
        ReadBool(values, "esp.fill", Menu::espFill); ReadFloat(values, "esp.fill.alpha", Menu::fillAlpha, 0.f, 1.f); ReadColor(values, "esp.fill.color", Menu::colEspFill); ReadRgb(values, "esp.fill.rgb", Menu::rgbEspFill);
        ReadBool(values, "esp.headCircle", Menu::espHeadCircle); ReadColor(values, "esp.headCircle.color", Menu::colEspHeadCircle); ReadRgb(values, "esp.headCircle.rgb", Menu::rgbEspHeadCircle);
        ReadBool(values, "esp.crosshair", Menu::customCrosshair); ReadInt(values, "esp.crosshair.mode", Menu::crosshairMode, 0, 2); ReadColor(values, "esp.crosshair.color", Menu::colCrosshair); ReadRgb(values, "esp.crosshair.rgb", Menu::rgbCrosshair);

        ReadBool(values, "aimbot.enabled", Aimbot::enabled); Menu::aimbotEnabled = Aimbot::enabled; ReadBool(values, "aimbot.useBind", Aimbot::useBind);
        ReadInt(values, "aimbot.bindKey", Menu::aimbotBindKey, 1, 255); ReadInt(values, "aimbot.bindMode", Menu::aimbotBindMode, 0, 1);
        ReadFloat(values, "aimbot.fov", Menu::aimbotFov, 1.f, 360.f); ReadFloat(values, "aimbot.smooth", Menu::aimbotSmooth, 0.1f, 20.f); ReadInt(values, "aimbot.target", Menu::aimbotTarget, 0, 2);
        ReadBool(values, "aimbot.workOnlyShooting", Menu::aimbotWorkOnlyShooting); ReadBool(values, "aimbot.showWhereToAim", Menu::aimbotShowWhereToAim); ReadBool(values, "aimbot.showFov", Aimbot::showFov);
        ReadColor(values, "aimbot.fov.color", Menu::colAimbotFov); ReadRgb(values, "aimbot.fov.rgb", Menu::rgbAimbotFov);
        Aimbot::bindKey = Menu::aimbotBindKey; Aimbot::bindMode = Menu::aimbotBindMode == 0 ? Switch : Tap; Aimbot::fov = Menu::aimbotFov; Aimbot::smooth = Menu::aimbotSmooth;
        Aimbot::targetMode = Menu::aimbotTarget; Aimbot::workOnlyShooting = Menu::aimbotWorkOnlyShooting; Aimbot::showWhereToAim = Menu::aimbotShowWhereToAim; Aimbot::ResetBind();

        ReadBool(values, "trigger.enabled", Trigger::trigger.triggerBot); ReadBool(values, "trigger.useBind", Trigger::trigger.useBind);
        ReadInt(values, "trigger.bindKey", Trigger::trigger.bindKey, 1, 255); int triggerMode = static_cast<int>(Trigger::trigger.bindMode);
        ReadInt(values, "trigger.bindMode", triggerMode, 0, 1); Trigger::trigger.bindMode = static_cast<TriggerBindMode>(triggerMode);
        ReadInt(values, "trigger.delayMs", Trigger::trigger.delayMs, 0, 500); Trigger::trigger.UpdateBindState();
    }
}

namespace ConfigSystem
{
    bool List(std::vector<std::string>& names, std::string& message)
    {
        names.clear();
        wchar_t appData[MAX_PATH]{};
        const DWORD length = GetEnvironmentVariableW(L"APPDATA", appData, ARRAYSIZE(appData));
        if (length == 0 || length >= ARRAYSIZE(appData))
        {
            message = "APPDATA path is unavailable.";
            return false;
        }
        const auto directory = std::filesystem::path(appData) / L"Solja X Marionets" / L"configs";
        std::error_code ec;
        if (!std::filesystem::exists(directory, ec))
        {
            message = "No configs yet. Save one to create it.";
            return true;
        }
        for (std::filesystem::directory_iterator it(directory, ec), end; !ec && it != end; it.increment(ec))
        {
            if (!it->is_regular_file(ec) || it->path().extension() != L".ini")
                continue;
            names.push_back(it->path().stem().string());
        }
        if (ec)
        {
            message = "Could not read the config folder.";
            return false;
        }
        std::sort(names.begin(), names.end(), [](const auto& a, const auto& b) {
            return _stricmp(a.c_str(), b.c_str()) < 0;
        });
        message = names.empty() ? "No configs yet. Save one to create it." : std::to_string(names.size()) + " config(s) found.";
        return true;
    }

    bool Save(const std::string& name, std::string& message)
    {
        std::filesystem::path path;
        if (!GetConfigPath(name, path, message, true)) return false;
        Fields fields;
        CollectFields(fields);
        std::ofstream file(path, std::ios::trunc);
        if (!file)
        {
            message = "Could not write config file.";
            return false;
        }
        file.imbue(std::locale::classic());
        file << "version=1\n";
        for (const auto& field : fields)
            file << field.first << '=' << field.second << '\n';
        if (!file)
        {
            message = "Config write failed.";
            return false;
        }
        message = "Saved config: " + name;
        return true;
    }

    bool Load(const std::string& name, std::string& message)
    {
        std::filesystem::path path;
        if (!GetConfigPath(name, path, message, false)) return false;
        std::ifstream file(path);
        if (!file)
        {
            message = "Config not found: " + name;
            return false;
        }
        Values values;
        std::string line;
        while (std::getline(file, line))
        {
            if (line.empty() || line[0] == ';' || line[0] == '#') continue;
            const auto separator = line.find('=');
            if (separator == std::string::npos || separator == 0) continue;
            values[line.substr(0, separator)] = line.substr(separator + 1);
        }
        if (values.empty())
        {
            message = "Config is empty or invalid.";
            return false;
        }
        ApplyValues(values);
        message = "Loaded config: " + name;
        return true;
    }
}
